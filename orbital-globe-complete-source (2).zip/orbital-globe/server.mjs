// Node.js 22+; local-only backend. Secrets stay on this side of the connection.
import http from "node:http";
import { createReadStream } from "node:fs";
import { stat, realpath } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { loadEnv } from "./backend/config.mjs";
import { createAviationService } from "./backend/aviation.mjs";
const rootURL = new URL("./", import.meta.url);
loadEnv(rootURL);
const root = fileURLToPath(rootURL);
const publicFiles = new Set([
  "index.html",
  "original.html",
  "app.js",
  "styles.css",
  "solar.js",
  "earth-shaders.js",
  "aviation-core.js",
  "globe-navigation.js",
  "aviation-ui.js",
  "aviation.css",
]);
const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".jpg": "image/jpeg",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ttf": "font/ttf",
};
function json(response, status, data) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  response.end(JSON.stringify(data));
}
export function createAppServer({ service = createAviationService() } = {}) {
  return http.createServer(async (request, response) => {
    try {
      if (!["GET", "HEAD"].includes(request.method))
        return json(response, 405, { error: "仅支持 GET / HEAD" });
      const url = new URL(request.url, "http://localhost");
      if (url.pathname.startsWith("/api/")) {
        if (request.method === "HEAD")
          return json(response, 405, { error: "API 请使用 GET" });
        const q = url.searchParams.get("q") || "";
        if (q.length > 100)
          return json(response, 400, { error: "搜索内容过长" });
        const family = url.searchParams.get("family") || "all";
        if (!["all", "A380", "B787"].includes(family))
          return json(response, 400, { error: "未知机型筛选" });
        if (url.pathname === "/api/meta")
          return json(response, 200, service.meta());
        if (url.pathname === "/api/airports") {
          const offset = Number(url.searchParams.get("offset") || 0),
            limit = Number(url.searchParams.get("limit") || 30);
          if (
            !Number.isInteger(offset) ||
            offset < 0 ||
            !Number.isInteger(limit) ||
            limit < 1 ||
            limit > 100
          )
            return json(response, 400, { error: "分页参数无效" });
          return json(
            response,
            200,
            service.searchAirports(q, family, offset, limit),
          );
        }
        if (url.pathname === "/api/flights")
          return json(
            response,
            200,
            await service.searchFlights(
              q,
              url.searchParams.get("live") === "1",
              family,
            ),
          );
        return json(response, 404, { error: "接口不存在" });
      }
      const pathname = decodeURIComponent(url.pathname);
      const relative = pathname === "/" ? "index.html" : pathname.slice(1);
      if (
        !publicFiles.has(relative) &&
        !/^assets\/[a-zA-Z0-9_.-]+$/.test(relative)
      )
        return json(response, 404, { error: "文件不存在" });
      const filename = await realpath(path.join(root, relative));
      if (!filename.startsWith(root))
        return json(response, 403, { error: "拒绝访问" });
      const info = await stat(filename);
      if (!info.isFile()) return json(response, 404, { error: "文件不存在" });
      response.writeHead(200, {
        "Content-Type":
          types[path.extname(filename)] || "application/octet-stream",
        "Content-Length": info.size,
        "Cache-Control": "no-cache",
        "X-Content-Type-Options": "nosniff",
      });
      if (request.method === "HEAD") response.end();
      else
        createReadStream(filename)
          .on("error", () => response.destroy())
          .pipe(response);
    } catch (error) {
      if (response.headersSent) {
        response.destroy();
        return;
      }
      const status =
        error instanceof URIError ? 400 : error.code === "ENOENT" ? 404 : 502;
      json(response, status, {
        error:
          status === 502
            ? "查询失败，请检查网络、后端配置或稍后重试。"
            : "请求或文件不存在",
      });
    }
  });
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  const port = Number(process.argv[2] || process.env.PORT || 8000);
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new Error("Invalid port");
  const server = createAppServer();
  server.on("error", (error) => {
    console.error(
      error.code === "EADDRINUSE"
        ? `端口 ${port} 已被占用，请关闭旧窗口或使用 node server.mjs 8080`
        : "服务启动失败",
    );
    process.exitCode = 1;
  });
  server.listen(port, "127.0.0.1", () => {
    console.log(`Orbital Aviation: http://127.0.0.1:${port}`);
    console.log(
      `Live data: ${process.env.AIRLABS_API_KEY && process.env.AIRLABS_API_KEY !== "YOUR_AIRLABS_API_KEY" ? "configured" : "not configured; airport and reference-route search available"}`,
    );
    console.log("Press Ctrl+C to stop.");
  });
}
