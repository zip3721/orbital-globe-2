import test from "node:test";
import assert from "node:assert/strict";
import * as THREE from "../assets/three.module.js";
import {
  orientationAt,
  northUpOrientation,
  clampZoom,
  scaleZoom,
  MIN_ZOOM,
  MAX_ZOOM,
  cameraDepth,
} from "../globe-navigation.js";
import { latLonVector } from "../aviation-core.js";

test("north-up centers a location and places geographic north above it", () => {
  for (const [lat, lon] of [
    [0, 0],
    [52.5, 13.4],
    [-33.9, 151.2],
    [70, -178],
    [-80, 179],
  ]) {
    const q = orientationAt(lat, lon);
    const center = new THREE.Vector3(...latLonVector(lat, lon)).applyQuaternion(
      q,
    );
    assert.ok(center.distanceTo(new THREE.Vector3(0, 0, 1)) < 1e-12);
    const north = new THREE.Vector3(
      ...latLonVector(lat + 0.01, lon),
    ).applyQuaternion(q);
    assert.ok(north.y > 0);
    assert.ok(Math.abs(north.x) < 1e-12);
  }
});

test("north-up removes screen roll without changing the center, including the poles", () => {
  for (const lat of [-90, -89.99, -34, 0, 52, 89.99, 90]) {
    for (const lon of [-180, -98, 0, 140]) {
      const rolled = orientationAt(lat, lon).premultiply(
        new THREE.Quaternion().setFromAxisAngle(
          new THREE.Vector3(0, 0, 1),
          2.4,
        ),
      );
      const upright = northUpOrientation(rolled);
      const center = new THREE.Vector3(0, 0, 1).applyQuaternion(
        rolled.clone().invert(),
      );
      assert.ok(
        center
          .clone()
          .applyQuaternion(upright)
          .distanceTo(new THREE.Vector3(0, 0, 1)) < 1e-8,
      );
      assert.ok(upright.toArray().every(Number.isFinite));
      if (Math.abs(lat) < 90) {
        const pole = new THREE.Vector3(0, 1, 0).applyQuaternion(upright);
        assert.ok(pole.y > 0);
        assert.ok(Math.abs(pole.x) < 1e-10);
      }
    }
  }
});

test("zoom supports 8x, clamps both limits, and keeps proportional controls reversible", () => {
  assert.equal(MAX_ZOOM, 8);
  assert.equal(clampZoom(100), 8);
  assert.equal(clampZoom(0), MIN_ZOOM);
  for (const level of [0.5, 1, 4, 7]) {
    assert.ok(scaleZoom(level, 0.12) > level);
    assert.ok(
      Math.abs(scaleZoom(scaleZoom(level, 0.12), -0.12) - level) < 1e-12,
    );
  }
});

test("the enlarged globe and atmosphere remain inside the camera depth range", () => {
  for (const radius of [160, 400, 800, 2000]) {
    const { z, far } = cameraDepth(radius);
    const extent = radius * MAX_ZOOM * 1.1;
    assert.ok(z - extent > 0.1);
    assert.ok(z + extent < far);
  }
});
