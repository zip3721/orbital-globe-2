import { test } from "node:test";
import assert from "node:assert/strict";
import {
  aircraftFamily,
  normalizeFlightNumber,
  greatCirclePoint,
  greatCirclePath,
  splitDateLine,
  routeDistanceKm,
  estimateFlightPosition,
  flightStatusText,
} from "../aviation-core.js";
import {
  normalizeLiveFlight,
  utcTime,
  createAviationService,
} from "../backend/aviation.mjs";
import { createAirLabs } from "../backend/airlabs.mjs";
import { createAppServer } from "../server.mjs";
const near = (a, b, e = 1e-6) => assert.ok(Math.abs(a - b) < e, `${a} != ${b}`);
const now = Date.parse("2026-10-20T12:00:00Z");
const flight = (extra = {}) => ({
  live: true,
  fetchedAt: new Date(now).toISOString(),
  status: "active",
  origin: { lat: 0, lon: 0 },
  destination: { lat: 0, lon: 90 },
  durationMinutes: 120,
  times: { estimatedArrival: "2026-10-20T13:00:00Z" },
  ...extra,
});

test("flight identifiers and all requested aircraft variants", () => {
  for (const [a, b] of [
    [" EK 001 ", "EK1"],
    ["ANA-184", "ANA184"],
    ["3U8633", "3U8633"],
    ["QF9", "QF9"],
    ["U2123", "U2123"],
  ])
    assert.equal(normalizeFlightNumber(a), b);
  for (const a of ["184", "AAA12345", "<script>", ""])
    assert.equal(normalizeFlightNumber(a), null);
  for (const type of ["B788", "B789", "B78X", "788", "789", "781"])
    assert.equal(aircraftFamily(type), "B787");
  assert.equal(aircraftFamily("A388"), "A380");
  assert.equal(aircraftFamily("B77W"), null);
});
test("route uses a shortest great circle including the date line", () => {
  near(greatCirclePoint([0, 0], [0, 90], 0.5)[1], 45);
  near(routeDistanceKm([0, 179], [0, -179]), 222.39016, 0.001);
  const paths = splitDateLine(greatCirclePath([35, 140], [21, -158]));
  assert.equal(paths.length, 2);
  for (const line of paths)
    for (let i = 1; i < line.length; i++)
      assert.ok(Math.abs(line[i][1] - line[i - 1][1]) <= 180);
  const points = greatCirclePath([40, -73], [1, 104]);
  const sum = points
    .slice(1)
    .reduce((total, p, i) => total + routeDistanceKm(points[i], p), 0);
  near(sum, routeDistanceKm(points[0], points.at(-1)), 0.01);
});
test("antipodal, coincident, near-antipodal and polar routes stay finite", () => {
  for (const [a, b] of [
    [
      [0, 0],
      [0, 180],
    ],
    [
      [10, 20],
      [10, 20],
    ],
    [
      [89.999, 0],
      [-89.999, 179.999],
    ],
    [
      [90, 0],
      [0, 0],
    ],
  ]) {
    const path = greatCirclePath(a, b);
    assert.deepEqual(path[0], a);
    assert.deepEqual(path.at(-1), b);
    for (const p of path) assert.ok(p.every(Number.isFinite));
  }
});
test("position follows ETA minus duration, with explicit estimate provenance", () => {
  const result = estimateFlightPosition(flight(), now);
  assert.equal(result.kind, "estimated");
  near(result.progress, 0.5);
  near(result.position[1], 45);
  assert.match(result.reason, /非雷达/);
});
test("scheduled, cancelled, diverted, landed and overdue flights are not falsely airborne", () => {
  assert.equal(
    estimateFlightPosition(flight({ status: "scheduled" }), now).kind,
    "ground",
  );
  for (const status of ["cancelled", "diverted", "unknown"])
    assert.equal(
      estimateFlightPosition(flight({ status }), now).position,
      null,
    );
  assert.equal(
    estimateFlightPosition(flight({ status: "landed" }), now).kind,
    "arrived",
  );
  assert.equal(
    estimateFlightPosition(flight(), now + 3600000).kind,
    "unavailable",
  );
});
test("missing, stale or contradictory timing never invents a position", () => {
  for (const changes of [
    { live: false },
    { stale: true },
    { fetchedAt: null },
    { durationMinutes: 0 },
    { durationMinutes: null },
    { times: {} },
    { times: { estimatedArrival: "2026-10-21T13:00:00Z" } },
    { fetchedAt: "2026-10-20T11:00:00Z" },
  ])
    assert.equal(estimateFlightPosition(flight(changes), now).position, null);
  assert.match(flightStatusText(flight({ arrivalDelayMinutes: null })), /未知/);
  assert.match(flightStatusText(flight({ arrivalDelayMinutes: 0 })), /准时/);
});
test("UTC timestamps, null delays and aircraft substitutions are normalized correctly", () => {
  assert.equal(utcTime({ dep_time: "2026-10-20 18:00" }, "dep_time"), null);
  assert.equal(
    utcTime({ dep_time_utc: "2026-10-20 18:00" }, "dep_time"),
    "2026-10-20T18:00:00.000Z",
  );
  const row = {
    flight_iata: "NH184",
    dep_iata: "NRT",
    arr_iata: "HNL",
    aircraft_icao: "B77W",
    status: "en-route",
    arr_time_utc: "2026-10-20 13:00",
    arr_estimated_utc: "2026-10-20 13:20",
    duration: 400,
  };
  const f = normalizeLiveFlight(row, (code) => ({ id: code, lat: 0, lon: 0 }), {
    aircraftType: "A388",
  });
  assert.equal(f.family, null);
  assert.equal(f.aircraftEvidence, "current");
  assert.equal(f.arrivalDelayMinutes, 20);
  const unknown = normalizeLiveFlight({ flight_iata: "NH184" }, () => null);
  assert.equal(unknown.arrivalDelayMinutes, null);
  assert.equal(unknown.origin, null);
});
test("airport search includes Chinese aliases, ICAO, exact IATA and evidence filters", () => {
  const service = createAviationService();
  assert.ok(service.meta().airports > 40000);
  assert.equal(service.searchAirports("KJFK").airports[0].iata, "JFK");
  assert.equal(service.searchAirports("NRT").airports[0].icao, "RJAA");
  assert.ok(
    service.searchAirports("上海").airports.some((a) => a.iata === "PVG"),
  );
  assert.equal(service.searchAirports("HNL", "A380").airports[0].iata, "HNL");
  assert.equal(service.meta().catalog.complete, false);
});
test("no API key returns honest offline results and never calls upstream", async () => {
  const provider = createAirLabs({
    apiKey: "",
    fetchImpl: () => {
      throw new Error("Must not fetch");
    },
  });
  const service = createAviationService({ provider });
  const result = await service.searchFlights("NH184", true);
  assert.equal(result.warnings[0].code, "KEY_MISSING");
  assert.equal(result.flights[0].live, false);
});
test("current queries retain multiple dates and legs and use request coalescing/cache", async () => {
  let calls = 0;
  const first = {
    flight_iata: "NH184",
    flight_icao: "ANA184",
    dep_iata: "NRT",
    arr_iata: "HNL",
    dep_time_ts: now / 1000 - 3600,
    arr_estimated_ts: now / 1000 + 3600,
    duration: 120,
    status: "en-route",
    aircraft_icao: "A388",
  };
  const provider = {
    configured: true,
    query: () => ({ flight_iata: "NH184" }),
    request: async (endpoint) => {
      calls++;
      await new Promise((r) => setTimeout(r, 5));
      return {
        response:
          endpoint === "flight"
            ? first
            : [
                first,
                {
                  ...first,
                  dep_time_ts: first.dep_time_ts + 86400,
                  status: "scheduled",
                },
                { ...first, arr_iata: "LAX" },
              ],
        request: { has_more: false },
      };
    },
  };
  const service = createAviationService({ provider, now: () => now });
  const [a, b] = await Promise.all([
    service.searchFlights("NH184", true),
    service.searchFlights("NH184", true),
  ]);
  assert.equal(calls, 2);
  assert.equal(a.flights.length, 3);
  assert.equal(new Set(a.flights.map((f) => f.id)).size, 3);
  assert.deepEqual(a, b);
  await service.searchFlights("NH184", true);
  assert.equal(calls, 2);
});
test("provider errors redact keys and handle quota/invalid JSON", async () => {
  const key = "test-secret-do-not-expose";
  for (const response of [
    new Response("{}", { status: 429 }),
    new Response("not-json", { status: 200 }),
    new Response(
      JSON.stringify({ error: { code: "access_denied", message: key } }),
      { status: 200 },
    ),
  ]) {
    const p = createAirLabs({ apiKey: key, fetchImpl: async () => response });
    await assert.rejects(p.request("flight"), (e) => !e.message.includes(key));
  }
});
test("a route-only provider result never turns into a simulated live flight", async () => {
  let routesRequested = false;
  const provider = {
    configured: true,
    query: () => ({ flight_iata: "QF9" }),
    request: async (endpoint) => {
      if (endpoint === "routes") {
        routesRequested = true;
        return {
          response: [
            {
              flight_iata: "QF9",
              dep_iata: "PER",
              arr_iata: "LHR",
              aircraft_icao: "B789",
              duration: 1020,
            },
          ],
          request: {},
        };
      }
      return { response: [], request: {} };
    },
  };
  const service = createAviationService({ provider, now: () => now });
  const result = await service.searchFlights("QF9", true);
  assert.ok(routesRequested);
  assert.equal(result.flights[0].live, false);
  assert.equal(estimateFlightPosition(result.flights[0], now).position, null);
});
test("upstream failure after cache expiry marks prior data stale", async () => {
  let clock = now,
    fail = false;
  const provider = {
    configured: true,
    query: () => ({ flight_iata: "NH184" }),
    request: async (endpoint) => {
      if (fail)
        throw Object.assign(new Error("Disconnected"), { code: "NETWORK" });
      return {
        response:
          endpoint === "flight"
            ? {
                flight_iata: "NH184",
                dep_iata: "NRT",
                arr_iata: "HNL",
                dep_time_ts: now / 1000 - 3600,
                arr_estimated_ts: now / 1000 + 3600,
                duration: 120,
                status: "en-route",
                aircraft_icao: "A388",
              }
            : [],
        request: {},
      };
    },
  };
  const service = createAviationService({ provider, now: () => clock });
  const first = await service.searchFlights("NH184", true);
  assert.ok(first.flights[0].live);
  clock += 121000;
  fail = true;
  const result = await service.searchFlights("NH184", true);
  assert.equal(result.flights[0].stale, true);
  assert.equal(estimateFlightPosition(result.flights[0], clock).position, null);
});
test("backend HTTP routes work; private files and invalid requests are blocked", async () => {
  const server = createAppServer();
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const meta = await (await fetch(base + "/api/meta")).json();
    assert.ok(meta.airports > 40000);
    const airports = await (await fetch(base + "/api/airports?q=EGLL")).json();
    assert.equal(airports.airports[0].iata, "LHR");
    assert.equal((await fetch(base + "/aviation-core.js")).status, 200);
    for (const pathname of [
      "/.env",
      "/.env.example",
      "/backend/config.mjs",
      "/data/airports.json",
      "/server.mjs",
      "/assets/../.env",
    ])
      assert.equal((await fetch(base + pathname)).status, 404);
    assert.equal(
      (await fetch(base + "/api/airports?limit=100000")).status,
      400,
    );
    assert.equal(
      (await fetch(base + "/api/meta", { method: "POST" })).status,
      405,
    );
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
