import assert from "node:assert/strict";
import { test } from "node:test";
import { readFileSync } from "node:fs";
import { getSolarState } from "../solar.js";
import * as THREE from "../assets/three.module.js";

const reference = JSON.parse(
  readFileSync(new URL("./noaa-reference.json", import.meta.url)),
);
const rad = Math.PI / 180;
const near = (actual, expected, tolerance = 1e-9) =>
  assert.ok(
    Math.abs(actual - expected) <= tolerance,
    `${actual} != ${expected} ± ${tolerance}`,
  );
const geo = (lat, lon) => [
  Math.cos(lat * rad) * Math.cos(lon * rad),
  Math.sin(lat * rad),
  -Math.cos(lat * rad) * Math.sin(lon * rad),
];
const dot = (a, b) => a.reduce((sum, n, i) => sum + n * b[i], 0);

test("matches the upstream NOAA calculator across seasons, leap day and year boundaries", () => {
  for (const row of reference.cases) {
    const solar = getSolarState(row.utc);
    near(solar.latitude, row.latitude);
    near(solar.equationOfTimeMinutes, row.equationOfTimeMinutes);
    near(Math.hypot(...solar.direction), 1);
  }
});

test("equivalent UTC and timezone-offset timestamps produce identical sunlight", () => {
  assert.deepEqual(
    getSolarState("2026-10-19T21:55:00+02:00"),
    getSolarState("2026-10-19T19:55:00Z"),
  );
});

test("the subsolar point is at solar noon, and its antipode is fully dark", () => {
  for (const row of reference.cases) {
    const solar = getSolarState(row.utc);
    near(dot(geo(solar.latitude, solar.longitude), solar.direction), 1);
    near(dot(geo(-solar.latitude, solar.longitude + 180), solar.direction), -1);
    const date = new Date(row.utc);
    const utcMinutes =
      date.getUTCHours() * 60 +
      date.getUTCMinutes() +
      date.getUTCSeconds() / 60 +
      date.getUTCMilliseconds() / 60000;
    const trueSolarTime =
      (((utcMinutes + solar.equationOfTimeMinutes + 4 * solar.longitude) %
        1440) +
        1440) %
      1440;
    near(trueSolarTime, 720);
  }
});

test("solar noon travels west by approximately 15 degrees per hour", () => {
  const a = getSolarState("2026-03-20T12:00:00Z");
  const b = getSolarState("2026-03-20T13:00:00Z");
  near(b.longitude - a.longitude, -15, 0.01);
  assert.ok(Math.abs(a.longitude) < 3 && Math.abs(a.latitude) < 1);
});

test("northern and southern polar daylight switch at the solstices", () => {
  const summer = getSolarState("2026-06-21T12:00:00Z");
  const winter = getSolarState("2026-12-21T12:00:00Z");
  near(summer.latitude, 23.44, 0.05);
  near(winter.latitude, -23.44, 0.05);
  assert.ok(dot(geo(90, 0), summer.direction) > 0);
  assert.ok(dot(geo(90, 0), winter.direction) < 0);
  assert.ok(dot(geo(-90, 0), winter.direction) > 0);
});

test("the Sun vector remains continuous across midnight, leap day and New Year", () => {
  for (const boundary of ["2024-03-01T00:00:00Z", "2027-01-01T00:00:00Z"]) {
    const time = Date.parse(boundary);
    const a = getSolarState(time - 1).direction;
    const b = getSolarState(time).direction;
    assert.ok(Math.hypot(...a.map((v, i) => v - b[i])) < 1e-6);
  }
});

test("2D UV-to-geography mapping matches the actual Three.js sphere", () => {
  const sphere = new THREE.SphereGeometry(1, 32, 16);
  const { position, uv } = sphere.attributes;
  for (let i = 0; i < position.count; i++) {
    if (Math.abs(position.getY(i)) > 0.999) continue;
    const mapped = geo((uv.getY(i) - 0.5) * 180, (uv.getX(i) - 0.5) * 360);
    near(mapped[0], position.getX(i), 1e-6);
    near(mapped[1], position.getY(i), 1e-6);
    near(mapped[2], position.getZ(i), 1e-6);
  }
  sphere.dispose();
});

test("invalid timestamps fail explicitly", () => {
  assert.throws(() => getSolarState("invalid"), RangeError);
});
