// Shared, dependency-free geometry and flight-time estimation.
export const TARGET_TYPES = new Set(["A388", "B788", "B789", "B78X"]);
export function aircraftFamily(type) {
  const code = String(type || "")
    .toUpperCase()
    .replace(/[ -]/g, "");
  if (["A388", "A380", "388"].includes(code)) return "A380";
  if (
    [
      "B788",
      "B789",
      "B78X",
      "B787",
      "788",
      "789",
      "781",
      "78X",
      "787",
      "7878",
      "7879",
      "78710",
    ].includes(code)
  )
    return "B787";
  return null;
}
export function normalizeFlightNumber(input) {
  const value = String(input || "")
    .toUpperCase()
    .replace(/[\s-]/g, "");
  const match = value.match(
    /^([A-Z][A-Z0-9]|[0-9][A-Z]|[A-Z]{3})(\d{1,4})([A-Z]?)$/,
  );
  if (!match) return null;
  return match[1] + String(Number(match[2])) + match[3];
}
export const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
export function latLonVector(lat, lon) {
  const a = (lat * Math.PI) / 180,
    b = (lon * Math.PI) / 180;
  return [Math.cos(a) * Math.cos(b), Math.sin(a), -Math.cos(a) * Math.sin(b)];
}
export function vectorLatLon(v) {
  const length = Math.hypot(...v);
  return [
    (Math.asin(clamp(v[1] / length, -1, 1)) * 180) / Math.PI,
    (Math.atan2(-v[2], v[0]) * 180) / Math.PI,
  ];
}
const dot = (a, b) => a.reduce((sum, n, i) => sum + n * b[i], 0);
export function greatCirclePoint(start, end, fraction) {
  const t = clamp(fraction, 0, 1);
  if (t === 0) return [...start];
  if (t === 1) return [...end];
  const a = latLonVector(...start),
    b = latLonVector(...end);
  const cosine = clamp(dot(a, b), -1, 1);
  const angle = Math.acos(cosine);
  if (angle < 1e-8) return [...start];
  let tangent = b.map((n, i) => n - cosine * a[i]);
  let length = Math.hypot(...tangent);
  // Exactly antipodal points have infinitely many shortest semicircles.
  if (length < 1e-10) {
    const basis = Math.abs(a[1]) < 0.8 ? [0, 1, 0] : [1, 0, 0];
    const projection = dot(a, basis);
    tangent = basis.map((n, i) => n - projection * a[i]);
    length = Math.hypot(...tangent);
  }
  const v = a.map(
    (n, i) =>
      n * Math.cos(angle * t) + (tangent[i] / length) * Math.sin(angle * t),
  );
  return vectorLatLon(v);
}
export function routeDistanceKm(start, end) {
  return (
    6371.0088 *
    Math.acos(clamp(dot(latLonVector(...start), latLonVector(...end)), -1, 1))
  );
}
export function greatCirclePath(start, end, segments = 192) {
  return Array.from({ length: segments + 1 }, (_, i) =>
    greatCirclePoint(start, end, i / segments),
  );
}
export function splitDateLine(points) {
  const paths = [[]];
  for (const point of points) {
    const line = paths.at(-1),
      previous = line.at(-1);
    if (previous && Math.abs(point[1] - previous[1]) > 180) {
      const unwrapped = point[1] + (point[1] < previous[1] ? 360 : -360);
      const edge = unwrapped > previous[1] ? 180 : -180;
      const t = (edge - previous[1]) / (unwrapped - previous[1]);
      const lat = previous[0] + (point[0] - previous[0]) * t;
      line.push([lat, edge]);
      paths.push([[lat, -edge]]);
    }
    paths.at(-1).push(point);
  }
  return paths;
}

export function estimateFlightPosition(flight, now = Date.now()) {
  const unavailable = (reason) => ({
    kind: "unavailable",
    position: null,
    progress: null,
    reason,
  });
  if (!flight?.origin || !flight?.destination)
    return unavailable("缺少机场坐标");
  if (!flight.live) return unavailable("离线航线记录没有当前航班位置");
  const fetched = Date.parse(flight.fetchedAt || "");
  if (flight.stale || !Number.isFinite(fetched) || now - fetched > 10 * 60000)
    return unavailable("状态数据已过期，请刷新");
  const from = [flight.origin.lat, flight.origin.lon],
    to = [flight.destination.lat, flight.destination.lon];
  if (["cancelled", "diverted"].includes(flight.status))
    return unavailable(
      flight.status === "cancelled" ? "航班已取消" : "航班备降，原航线不再适用",
    );
  if (flight.status === "landed")
    return {
      kind: "arrived",
      position: to,
      progress: 1,
      reason: "数据源报告已到达",
    };
  if (flight.status === "scheduled")
    return {
      kind: "ground",
      position: from,
      progress: 0,
      reason: "尚未报告起飞",
    };
  if (flight.status !== "active") return unavailable("尚无可确认的飞行中状态");
  const eta = Date.parse(flight.times?.estimatedArrival || "");
  const minutes = Number(flight.durationMinutes);
  if (!Number.isFinite(eta))
    return unavailable("缺少预计到达时间，无法估算位置");
  if (!Number.isFinite(minutes) || minutes <= 0 || minutes > 24 * 60)
    return unavailable("缺少有效的预计飞行时长");
  if (now >= eta) return unavailable("已超过预计到达时间，尚待确认落地");
  const start = eta - minutes * 60000;
  if (now < start) return unavailable("预计时长与当前飞行状态不一致");
  const progress = clamp((now - start) / (minutes * 60000), 0, 1);
  return {
    kind: "estimated",
    position: greatCirclePoint(from, to, progress),
    progress,
    inferredDeparture: new Date(start).toISOString(),
    estimatedArrival: flight.times.estimatedArrival,
    reason: "按预计到达时间和飞行时长沿最短大圆估算；非雷达位置",
  };
}

export function flightStatusText(flight) {
  if (!flight.live) return "离线参考航线 · 状态未知";
  if (flight.stale) return "状态已过期";
  const base =
    {
      scheduled: "待起飞",
      active: "飞行中",
      landed: "已到达",
      cancelled: "已取消",
      diverted: "备降",
      unknown: "状态未知",
    }[flight.status] || "状态未知";
  if (["cancelled", "diverted"].includes(flight.status)) return base;
  const delay = flight.arrivalDelayMinutes;
  return (
    base +
    (delay == null
      ? " · 延误信息未知"
      : delay > 0
        ? ` · 预计到达晚点 ${Math.round(delay)} 分钟`
        : delay < 0
          ? ` · 预计提前 ${Math.round(-delay)} 分钟`
          : " · 预计准时")
  );
}
