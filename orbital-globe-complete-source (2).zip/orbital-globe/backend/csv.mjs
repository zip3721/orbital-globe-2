export function parseCSV(text) {
  const rows = [];
  let row = [],
    cell = "",
    quoted = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === '"') {
      if (quoted && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[i + 1] === "\n") i++;
      row.push(cell);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
    } else cell += char;
  }
  if (quoted) throw new Error("CSV 中存在未闭合的引号");
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  const header = rows.shift()?.map((v) => v.replace(/^\uFEFF/, "")) || [];
  return rows.map((values) =>
    Object.fromEntries(header.map((key, index) => [key, values[index] || ""])),
  );
}
