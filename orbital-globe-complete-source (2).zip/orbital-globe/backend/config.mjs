import { readFileSync } from "node:fs";
export function loadEnv(root) {
  let text;
  try {
    text = readFileSync(new URL(".env", root), "utf8");
  } catch (e) {
    if (e.code === "ENOENT") return;
    throw e;
  }
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match || process.env[match[1]] !== undefined) continue;
    const value = match[2].replace(/^(["'])(.*)\1$/, "$2");
    process.env[match[1]] = value;
  }
}
