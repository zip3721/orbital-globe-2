import { normalizeFlightNumber } from "../aviation-core.js";
export class ProviderError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}
export function createAirLabs({
  apiKey = process.env.AIRLABS_API_KEY,
  fetchImpl = fetch,
  timeoutMs = 15000,
} = {}) {
  async function request(endpoint, params = {}) {
    if (!apiKey || apiKey === "YOUR_AIRLABS_API_KEY")
      throw new ProviderError(
        "KEY_MISSING",
        "尚未配置 AirLabs API Key。可搜索本地机场和参考航线。",
      );
    const url = new URL(`https://airlabs.co/api/v9/${endpoint}`);
    url.searchParams.set("api_key", apiKey);
    for (const [key, value] of Object.entries(params))
      if (value != null) url.searchParams.set(key, String(value));
    let response;
    try {
      response = await fetchImpl(url, {
        signal: AbortSignal.timeout(timeoutMs),
        redirect: "error",
      });
    } catch {
      throw new ProviderError(
        "NETWORK",
        "航班数据服务连接失败或超时，请稍后重试。",
      );
    }
    if (response.status === 401 || response.status === 403)
      throw new ProviderError(
        "AUTH",
        "航班数据服务拒绝访问，请检查密钥与套餐权限。",
      );
    if (response.status === 429)
      throw new ProviderError("QUOTA", "航班数据服务请求额度或频率已达上限。");
    if (!response.ok)
      throw new ProviderError("UPSTREAM", "航班数据服务暂时不可用。");
    let body;
    try {
      body = await response.json();
    } catch {
      throw new ProviderError("FORMAT", "航班数据服务返回格式异常。");
    }
    if (body.error) {
      const code = String(body.error.code || "");
      const message = String(body.error.message || "");
      if (/not found|no data/i.test(message))
        return { response: [], request: { has_more: false } };
      throw new ProviderError(
        "PROVIDER",
        `数据服务请求未获批准（${code.replace(/[^\w-]/g, "").slice(0, 40) || "unknown"}），请检查账户权限或额度。`,
      );
    }
    if (!("response" in body))
      throw new ProviderError("FORMAT", "航班数据服务未返回数据字段。");
    // Never return request metadata (which may echo the API key) to the browser.
    return {
      response: body.response,
      request: { has_more: body.request?.has_more },
    };
  }
  function query(number) {
    const normalized = normalizeFlightNumber(number);
    if (!normalized)
      throw new ProviderError(
        "NUMBER",
        "请输入完整航班号，例如 NH184 或 ANA184。",
      );
    const isICAO = /^[A-Z]{3}\d/.test(normalized);
    return { [isICAO ? "flight_icao" : "flight_iata"]: normalized };
  }
  return {
    configured: Boolean(apiKey && apiKey !== "YOUR_AIRLABS_API_KEY"),
    request,
    query,
  };
}
