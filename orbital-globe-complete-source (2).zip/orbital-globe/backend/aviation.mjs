import { readFileSync, existsSync } from "node:fs";
import { aircraftFamily, normalizeFlightNumber } from "../aviation-core.js";
import { createAirLabs } from "./airlabs.mjs";

const numberValue = (value) =>
  value == null || value === "" || !Number.isFinite(Number(value))
    ? null
    : Number(value);
export function utcTime(row, name) {
  const seconds = numberValue(row[`${name}_ts`]);
  if (
    seconds != null &&
    seconds > 0 &&
    Number.isFinite(new Date(seconds * 1000).getTime())
  )
    return new Date(seconds * 1000).toISOString();
  const text = row[`${name}_utc`];
  if (
    typeof text !== "string" ||
    !/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/.test(text)
  )
    return null;
  const iso =
    text.replace(" ", "T") + (/Z$|[+-]\d{2}:?\d{2}$/.test(text) ? "" : "Z");
  return Number.isFinite(Date.parse(iso)) ? new Date(iso).toISOString() : null;
}
function cleanNumber(value) {
  return normalizeFlightNumber(value) || String(value || "").slice(0, 20);
}
function normalStatus(value) {
  return (
    {
      "en-route": "active",
      active: "active",
      airborne: "active",
      scheduled: "scheduled",
      landed: "landed",
      arrived: "landed",
      cancelled: "cancelled",
      canceled: "cancelled",
      diverted: "diverted",
    }[String(value).toLowerCase()] || "unknown"
  );
}
export function normalizeLiveFlight(
  row,
  resolveAirport,
  fallback = null,
  fetchedAt = new Date().toISOString(),
) {
  const origin = resolveAirport(row.dep_icao) || resolveAirport(row.dep_iata);
  const destination =
    resolveAirport(row.arr_icao) || resolveAirport(row.arr_iata);
  const times = Object.fromEntries(
    Object.entries({
      scheduledDeparture: "dep_time",
      scheduledArrival: "arr_time",
      estimatedDeparture: "dep_estimated",
      estimatedArrival: "arr_estimated",
      actualDeparture: "dep_actual",
      actualArrival: "arr_actual",
    }).map(([key, field]) => [key, utcTime(row, field)]),
  );
  const currentType = row.aircraft_icao || null;
  const aircraftType = currentType || fallback?.aircraftType || null;
  let arrivalDelayMinutes = numberValue(row.arr_delayed);
  if (
    arrivalDelayMinutes == null &&
    times.scheduledArrival &&
    (times.actualArrival || times.estimatedArrival)
  )
    arrivalDelayMinutes = Math.round(
      (Date.parse(times.actualArrival || times.estimatedArrival) -
        Date.parse(times.scheduledArrival)) /
        60000,
    );
  let durationMinutes = numberValue(row.duration);
  let durationBasis = "provider";
  if (
    !(durationMinutes > 0) &&
    times.scheduledArrival &&
    times.scheduledDeparture
  ) {
    durationMinutes =
      (Date.parse(times.scheduledArrival) -
        Date.parse(times.scheduledDeparture)) /
      60000;
    durationBasis = "schedule-difference";
  }
  if (!(durationMinutes > 0 && durationMinutes <= 1440)) durationMinutes = null;
  const number = cleanNumber(row.flight_iata || row.flight_icao);
  return {
    id: [
      number,
      row.dep_icao || row.dep_iata,
      row.arr_icao || row.arr_iata,
      times.scheduledDeparture || "undated",
    ].join("|"),
    number,
    icaoNumber: cleanNumber(row.flight_icao),
    operator: row.airline_name || row.airline_iata || row.airline_icao || "",
    codeshare: row.cs_flight_iata || null,
    aircraftType,
    family: aircraftFamily(aircraftType),
    aircraftEvidence: currentType
      ? "current"
      : aircraftType
        ? "catalog"
        : "unknown",
    passengerEvidence: fallback?.passengerEvidence || "provider-unclassified",
    origin,
    destination,
    originCode: row.dep_iata || row.dep_icao,
    destinationCode: row.arr_iata || row.arr_icao,
    status: normalStatus(row.status),
    times,
    durationMinutes,
    durationBasis,
    arrivalDelayMinutes,
    source: "AirLabs",
    sourceUrl: "https://airlabs.co/docs/flight",
    fetchedAt,
    providerUpdatedAt:
      numberValue(row.updated) > 0
        ? new Date(Number(row.updated) * 1000).toISOString()
        : null,
    live: true,
    stale: false,
  };
}

export function createAviationService({
  root = new URL("../", import.meta.url),
  provider = createAirLabs(),
  now = Date.now,
} = {}) {
  const read = (name, fallback) => {
    const url = new URL(`data/${name}`, root);
    return existsSync(url) ? JSON.parse(readFileSync(url, "utf8")) : fallback;
  };
  const airportData = read("airports.json", { metadata: {}, airports: [] });
  const catalogFile = read("flights.catalog.json", {
    metadata: {},
    flights: [],
  });
  const seeds = read("flights.seed.json", { flights: [] });
  const compatibility = read("compatibility.json", { airports: [] });
  const byCode = new Map();
  const airports = airportData.airports.map((a) => ({ ...a, evidence: [] }));
  for (const a of airports)
    for (const code of [a.id, a.icao, a.iata])
      if (code) byCode.set(String(code).toUpperCase(), a);
  const resolveAirport = (code) =>
    code ? byCode.get(String(code).toUpperCase()) || null : null;
  function recordEvidence(code, evidence) {
    const airport = resolveAirport(code);
    if (!airport) return;
    if (
      !airport.evidence.some(
        (e) => e.family === evidence.family && e.source === evidence.source,
      )
    )
      airport.evidence.push(evidence);
  }
  for (const a of compatibility.airports)
    recordEvidence(a.code, {
      family: a.family,
      kind: a.kind,
      source: a.source,
      asOf: a.asOf,
    });
  const catalogMap = new Map();
  for (const row of [...seeds.flights, ...catalogFile.flights]) {
    const number = normalizeFlightNumber(row.number);
    if (!number || !aircraftFamily(row.aircraftType)) continue;
    const origin = resolveAirport(row.originCode),
      destination = resolveAirport(row.destinationCode);
    const id = [number, row.originCode, row.destinationCode].join("|");
    const flight = {
      ...row,
      id,
      number,
      family: aircraftFamily(row.aircraftType),
      origin,
      destination,
      status: "unknown",
      live: false,
      stale: false,
      times: {},
      arrivalDelayMinutes: null,
      aircraftEvidence: "catalog",
    };
    catalogMap.set(id, flight);
    for (const code of [row.originCode, row.destinationCode])
      recordEvidence(code, {
        family: flight.family,
        kind: "service-history",
        source: row.sourceUrl,
        asOf: row.sourceAsOf || row.fetchedAt || null,
      });
  }
  const catalog = [...catalogMap.values()];
  const fold = (s) =>
    String(s || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  const index = airports.map((airport) => ({
    airport,
    text: fold(
      [
        airport.id,
        airport.iata,
        airport.icao,
        airport.name,
        airport.city,
        airport.country,
        ...(airport.aliases || []),
      ].join(" "),
    ),
  }));
  const cache = new Map(),
    inflight = new Map();
  const meta = () => ({
    airports: airports.length,
    catalogRoutes: catalog.length,
    airportsWithEvidence: airports.filter((a) => a.evidence.length).length,
    provider: "AirLabs",
    liveConfigured: provider.configured,
    refreshSeconds: 120,
    airportSource: airportData.metadata,
    catalog: catalogFile.metadata,
    coverage:
      "机场坐标库不是机型适航批准清单；机型标记来自具名来源或航线使用记录。内置航线只是参考，全球完整航班库需经授权数据同步，机型可能临时变更。",
  });
  function searchAirports(q = "", family = "all", offset = 0, limit = 30) {
    const query = fold(q.trim());
    const matches = index.filter(
      ({ airport: a, text }) =>
        (!query || text.includes(query)) &&
        (family === "all" || a.evidence.some((e) => e.family === family)),
    );
    const rank = (a) =>
      ([a.iata, a.icao, a.id].some((s) => fold(s) === query) ? 0 : 1) * 100 +
      (a.type === "large_airport" ? 0 : a.type === "medium_airport" ? 10 : 20) -
      (a.evidence.length ? 5 : 0);
    matches.sort(
      (a, b) =>
        rank(a.airport) - rank(b.airport) ||
        a.airport.name.localeCompare(b.airport.name),
    );
    return {
      airports: matches
        .slice(offset, offset + limit)
        .map((item) => item.airport),
      total: matches.length,
      offset,
      limit,
    };
  }
  function localFlights(q = "", family = "all") {
    const raw = fold(q),
      normalized = normalizeFlightNumber(q);
    return catalog.filter(
      (f) =>
        (family === "all" || f.family === family) &&
        (!q ||
          [f.number, f.icaoNumber, ...(f.codeshares || [])].includes(
            normalized,
          ) ||
          fold(
            [
              f.number,
              f.icaoNumber,
              f.operator,
              f.originCode,
              f.destinationCode,
            ].join(" "),
          ).includes(raw)),
    );
  }
  const matchRoute = (row) =>
    catalog.find(
      (f) =>
        [f.number, f.icaoNumber].includes(
          cleanNumber(row.flight_iata || row.flight_icao),
        ) &&
        [f.origin?.iata, f.origin?.icao].includes(
          row.dep_iata || row.dep_icao,
        ) &&
        [f.destination?.iata, f.destination?.icao].includes(
          row.arr_iata || row.arr_icao,
        ),
    );
  const sameOccurrence = (a, b) =>
    (a.dep_icao || a.dep_iata) === (b.dep_icao || b.dep_iata) &&
    (a.arr_icao || a.arr_iata) === (b.arr_icao || b.arr_iata) &&
    utcTime(a, "dep_time") &&
    utcTime(b, "dep_time") &&
    Math.abs(
      Date.parse(utcTime(a, "dep_time")) - Date.parse(utcTime(b, "dep_time")),
    ) <
      5 * 60000;
  async function liveLookup(number) {
    const cached = cache.get(number);
    if (cached && now() - cached.time < 120000)
      return { ...cached.result, cached: true };
    if (inflight.has(number)) return inflight.get(number);
    const job = (async () => {
      const params = provider.query(number);
      const outcomes = await Promise.allSettled([
        provider.request("flight", params),
        provider.request("schedules", { ...params, limit: 50 }),
      ]);
      const warnings = [],
        rows = [];
      let detail = null;
      if (outcomes[0].status === "fulfilled") {
        const data = outcomes[0].value.response;
        detail =
          !Array.isArray(data) && data && Object.keys(data).length
            ? data
            : null;
      } else
        warnings.push({
          code: outcomes[0].reason.code,
          message: outcomes[0].reason.message,
        });
      if (outcomes[1].status === "fulfilled") {
        const data = outcomes[1].value.response;
        if (Array.isArray(data)) rows.push(...data);
        if (outcomes[1].value.request?.has_more)
          warnings.push({
            code: "TRUNCATED",
            message: "数据源还有其他班次，本次返回前 50 条；请缩小查询范围。",
          });
      } else
        warnings.push({
          code: outcomes[1].reason.code,
          message: outcomes[1].reason.message,
        });
      if (detail) {
        const index = rows.findIndex((row) => sameOccurrence(row, detail));
        if (index >= 0)
          rows[index] = {
            ...rows[index],
            ...Object.fromEntries(
              Object.entries(detail).filter(([, v]) => v != null),
            ),
          };
        else rows.push(detail);
      }
      const fetchedAt = new Date(now()).toISOString();
      let flights = rows.map((row) =>
        normalizeLiveFlight(row, resolveAirport, matchRoute(row), fetchedAt),
      );
      flights = [...new Map(flights.map((f) => [f.id, f])).values()];
      if (!flights.length && outcomes.every((r) => r.status === "rejected")) {
        if (cached)
          return {
            ...cached.result,
            flights: cached.result.flights.map((f) => ({ ...f, stale: true })),
            warnings,
            stale: true,
          };
        return { flights: [], warnings, fetchedAt, cached: false };
      }
      // A valid number may have no current occurrence. Fall back to the route
      // database, still labelling it as a non-live, last-aircraft-used record.
      if (!flights.length) {
        try {
          const routes = await provider.request("routes", {
            ...params,
            limit: 50,
          });
          if (Array.isArray(routes.response))
            flights = routes.response
              .filter((r) => aircraftFamily(r.aircraft_icao))
              .map((r) => {
                const f = normalizeLiveFlight(
                  r,
                  resolveAirport,
                  null,
                  fetchedAt,
                );
                return {
                  ...f,
                  id: [f.number, f.originCode, f.destinationCode, "route"].join(
                    "|",
                  ),
                  live: false,
                  status: "unknown",
                  times: {},
                  arrivalDelayMinutes: null,
                  aircraftEvidence: "catalog",
                  source: "AirLabs route database (last used aircraft)",
                  sourceUrl: "https://airlabs.co/docs/routes",
                  sourceAsOf: r.updated || null,
                };
              });
          if (routes.request?.has_more)
            warnings.push({
              code: "TRUNCATED",
              message: "参考航线返回前 50 条，请同步航线库以获取更多记录。",
            });
          if (flights.length)
            warnings.push({
              code: "ROUTE_ONLY",
              message: "未找到当前班次，显示数据源的参考航线；不是实时状态。",
            });
        } catch (error) {
          warnings.push({ code: error.code, message: error.message });
        }
      }
      const result = { flights, warnings, fetchedAt, cached: false };
      cache.set(number, { time: now(), result });
      if (cache.size > 200) cache.delete(cache.keys().next().value);
      return result;
    })();
    inflight.set(number, job);
    try {
      return await job;
    } finally {
      inflight.delete(number);
    }
  }
  async function searchFlights(q, live = false, family = "all") {
    const local = localFlights(q, family);
    if (!live)
      return {
        flights: local.slice(0, 100),
        total: local.length,
        liveAttempted: false,
        warnings: [],
      };
    const number = normalizeFlightNumber(q);
    if (!number)
      return {
        flights: local.slice(0, 100),
        warnings: [
          {
            code: "NUMBER",
            message: "联网查询需要完整航班号，例如 NH184、QF9 或 ANA184。",
          },
        ],
      };
    if (!provider.configured)
      return {
        flights: local.slice(0, 100),
        liveAttempted: false,
        warnings: [
          {
            code: "KEY_MISSING",
            message:
              "实时数据未启用：请在本机 .env 中配置 AIRLABS_API_KEY。下方仅为离线参考航线。",
          },
        ],
      };
    const result = await liveLookup(number);
    return {
      ...result,
      flights: result.flights.length ? result.flights : local,
      liveAttempted: true,
      usedOfflineFallback: !result.flights.length,
    };
  }
  return { meta, searchAirports, searchFlights, resolveAirport };
}
