// Solar declination and equation of time: NOAA's Meeus-based solar calculator.
// https://gml.noaa.gov/grad/solcalc/main.js
// All calculations use UTC, independently of the browser's local timezone.
const DEG = Math.PI / 180;
const wrap = (angle, period) => ((angle % period) + period) % period;

export function getSolarState(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  const timestamp = date.getTime();
  if (!Number.isFinite(timestamp)) throw new RangeError("Invalid solar date");

  const julianDay = timestamp / 86400000 + 2440587.5;
  const t = (julianDay - 2451545) / 36525;
  const meanLongitude = wrap(
    280.46646 + t * (36000.76983 + 0.0003032 * t),
    360,
  );
  const meanAnomaly = (357.52911 + t * (35999.05029 - 0.0001537 * t)) * DEG;
  const eccentricity = 0.016708634 - t * (0.000042037 + 0.0000001267 * t);
  const center =
    Math.sin(meanAnomaly) * (1.914602 - t * (0.004817 + 0.000014 * t)) +
    Math.sin(2 * meanAnomaly) * (0.019993 - 0.000101 * t) +
    Math.sin(3 * meanAnomaly) * 0.000289;
  const omega = (125.04 - 1934.136 * t) * DEG;
  const apparentLongitude =
    (meanLongitude + center - 0.00569 - 0.00478 * Math.sin(omega)) * DEG;
  const obliquitySeconds = 21.448 - t * (46.815 + t * (0.00059 - t * 0.001813));
  const obliquity =
    (23 + (26 + obliquitySeconds / 60) / 60 + 0.00256 * Math.cos(omega)) * DEG;
  const declination = Math.asin(
    Math.sin(obliquity) * Math.sin(apparentLongitude),
  );

  const y = Math.tan(obliquity / 2) ** 2;
  const l0 = meanLongitude * DEG;
  const equationOfTimeMinutes =
    (4 / DEG) *
    (y * Math.sin(2 * l0) -
      2 * eccentricity * Math.sin(meanAnomaly) +
      4 * eccentricity * y * Math.sin(meanAnomaly) * Math.cos(2 * l0) -
      0.5 * y * y * Math.sin(4 * l0) -
      1.25 * eccentricity * eccentricity * Math.sin(2 * meanAnomaly));
  const utcMinutes =
    date.getUTCHours() * 60 +
    date.getUTCMinutes() +
    date.getUTCSeconds() / 60 +
    date.getUTCMilliseconds() / 60000;
  // At the subsolar longitude, true solar time is exactly 720 minutes.
  const longitude =
    wrap(180 - (utcMinutes + equationOfTimeMinutes) / 4 + 180, 360) - 180;
  const latitude = declination / DEG;
  const lon = longitude * DEG;
  const cosDec = Math.cos(declination);
  return {
    timestamp,
    latitude,
    longitude,
    equationOfTimeMinutes,
    // Same Earth-fixed coordinates as geo(): +X Greenwich, +Y north, -Z east.
    direction: [
      cosDec * Math.cos(lon),
      Math.sin(declination),
      -cosDec * Math.sin(lon),
    ],
  };
}
