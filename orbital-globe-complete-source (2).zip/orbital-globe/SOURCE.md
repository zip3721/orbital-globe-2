# 获取与整理记录

- 页面：https://hqman.me/demo/gpt-6-astra-3d-globe/?utm_source=chatgpt.com
- 获取日期：2026-10-19（UTC）。
- 范围：目标公开页面的 HTML，以及页面明确引用的 9 个静态资源。
- 没有访问私有源码仓库、管理接口或后端实现。

## 原始 HTML

`original.html` 保留了获取到的完整响应内容，SHA-256：

```text
d10fdf1ae3275f24d7f391ff0d1020375e880e29784520ab9838efe8dca571e5
```

## 最初整理（1.0.0）

1. 将原始 `<style>` 内容提取到 `styles.css`。
2. 将原始 `<script type="module">` 内容提取到 `app.js`。
3. `index.html` 改为引用这两个文件，其余页面内容保持一致。
4. 使用 Prettier 3.6.2 格式化三个拆分文件；不格式化或改写 `original.html` 和 `assets/`。
5. 添加本地启动脚本、说明文档、资源清单和第三方声明。

最初整理版的业务逻辑、配色、纹理、货运数据、SVG 图标和内嵌着色器均来自原页。

## 本次修改（1.1.0）

按用户要求增加了真实时间昼夜照明与白昼隐藏城市灯光，修改范围见 `CHANGES.md`。现在 `app.js` 的照明逻辑已与原页不同，不能再将其视为原始内联 JavaScript 的等价排版版本。`original.html` 和 9 个原始资源仍未改动。

## 最初整理时的校验

- 拆分前验证 CSS 与 JavaScript 均从原始内联内容完整提取。
- 比较原始内联 JavaScript 与格式化后 `app.js` 的解析语法树，去除位置及排版元数据后完全一致。
- Node.js 检查应用、启动脚本及依赖脚本的 JavaScript 语法。
- 检查 HTML / CSS / JavaScript 的本地静态资源引用。
- 解码检查三张地球图片，解析两份 TrueType 字体。
- 对原始 HTML 和 9 个原始资源计算并记录 SHA-256。
- 对最终 ZIP 检查条目及 CRC。

实时昼夜版本的新增测试结果见 `CHANGES.md`。未执行整页浏览器截图或交互验收。没有还原不可从公开页面取得的开发历史、原始 JSX、私有构建配置或服务器代码。

## 航空搜索版本（2.0.0）

新增航空搜索、后台 API、机型识别与数据同步/导入，详见 `FLIGHT-SETUP.md`。机场及跑道源文件于 2026-10-20 从 OurAirports 官方数据仓库获取，仅保留有效坐标的固定翼机场。内置参考航线逐条保存来源与资料日期。没有真实 AirLabs 密钥，没有冒充已经完成全球全量航班数据导入。

原站 `original.html` 与 `asset-manifest.json` 所列 9 个原始资源仍未改动。
