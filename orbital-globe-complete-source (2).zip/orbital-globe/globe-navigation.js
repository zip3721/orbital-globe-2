import * as THREE from "./assets/three.module.js";

export const MIN_ZOOM = 0.28;
export const MAX_ZOOM = 8;
export const clampZoom = (value) =>
  THREE.MathUtils.clamp(value, MIN_ZOOM, MAX_ZOOM);
export const scaleZoom = (value, amount) => clampZoom(value * Math.exp(amount));

// The rows are geographic east, north and outward: north is screen-up.
export function orientationAt(latitude, longitude) {
  const lat = THREE.MathUtils.degToRad(latitude);
  const lon = THREE.MathUtils.degToRad(longitude);
  const east = new THREE.Vector3(-Math.sin(lon), 0, -Math.cos(lon));
  const north = new THREE.Vector3(
    -Math.sin(lat) * Math.cos(lon),
    Math.cos(lat),
    Math.sin(lat) * Math.sin(lon),
  );
  const outward = new THREE.Vector3(
    Math.cos(lat) * Math.cos(lon),
    Math.sin(lat),
    -Math.cos(lat) * Math.sin(lon),
  );
  return new THREE.Quaternion().setFromRotationMatrix(
    new THREE.Matrix4().makeBasis(east, north, outward).transpose(),
  );
}

export function northUpOrientation(rotation) {
  const inverse = rotation.clone().invert();
  const center = new THREE.Vector3(0, 0, 1).applyQuaternion(inverse);
  let lon = Math.atan2(-center.z, center.x);
  // At a pole, preserve the existing screen-right meridian to avoid a jump.
  if (Math.hypot(center.x, center.z) < 1e-8) {
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(inverse);
    lon = Math.atan2(-right.x, -right.z);
  }
  return orientationAt(
    THREE.MathUtils.radToDeg(Math.atan2(center.y, Math.hypot(center.x, center.z))),
    THREE.MathUtils.radToDeg(lon),
  );
}

export function cameraDepth(radius) {
  const z = Math.max(1500, radius * MAX_ZOOM * 3 + 100);
  return { z, far: z * 2 };
}
