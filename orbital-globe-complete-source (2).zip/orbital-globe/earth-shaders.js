// Sun direction is Earth-fixed. Camera rotation must never change local time.
export const surfaceVertexShader = /* glsl */ `
  varying vec2 vUv;
  varying vec3 vEarthNormal;
  varying vec3 vViewNormal;
  void main() {
    vUv = uv;
    vEarthNormal = normal;
    vViewNormal = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

export const surfaceFragmentShader = /* glsl */ `
  precision highp float;
  uniform sampler2D dayMap;
  uniform sampler2D nightMap;
  uniform sampler2D cloudMap;
  uniform vec3 sunDirection;
  uniform float cloudOffset;
  uniform float flatMap;
  varying vec2 vUv;
  varying vec3 vEarthNormal;
  varying vec3 vViewNormal;

  // Textures remain NoColorSpace; conversion happens explicitly here.
  vec3 srgbToLinear(vec3 c) {
    return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
  }
  vec3 linearToSrgb(vec3 c) {
    c = max(c, vec3(0.0));
    return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
  }
  void main() {
    vec3 earthNormal = normalize(vEarthNormal);
    if (flatMap > 0.5) {
      float lon = (vUv.x - 0.5) * 6.28318530718;
      float lat = (vUv.y - 0.5) * 3.14159265359;
      earthNormal = vec3(cos(lat) * cos(lon), sin(lat), -cos(lat) * sin(lon));
    }
    float sunHeight = dot(earthNormal, normalize(sunDirection));
    float directSun = max(sunHeight, 0.0);
    float twilight = smoothstep(-0.104528463, 0.08, sunHeight);
    // EXACTLY zero at and above the geometric horizon. Fade in from 0 to -6°.
    float cityVisibility = 1.0 - smoothstep(-0.104528463, 0.0, sunHeight);

    vec3 day = srgbToLinear(texture2D(dayMap, vUv).rgb);
    vec3 night = texture2D(nightMap, vUv).rgb;
    vec3 cloudSample = texture2D(cloudMap, vec2(fract(vUv.x + cloudOffset), vUv.y)).rgb;
    float cloud = smoothstep(0.1, 0.9, dot(cloudSample, vec3(0.333333)));
    vec3 surface = day * (0.006 + 0.10 * twilight + 1.25 * directSun);
    surface += vec3(0.0005, 0.001, 0.003) * (1.0 - twilight);
    vec3 cloudColor = vec3(1.0, 0.98, 0.94) * (0.004 + 0.10 * twilight + 1.1 * directSun);
    surface = mix(surface, cloudColor, cloud * 0.78);
    float lights = max(dot(night, vec3(0.299, 0.587, 0.114)) - 0.045, 0.0);
    vec3 city = vec3(1.0, 0.73, 0.36) * pow(lights, 0.8) * 1.6;
    surface += city * cityVisibility * (1.0 - cloud * 0.75);

    if (flatMap < 0.5) {
      float rim = pow(1.0 - abs(normalize(vViewNormal).z), 3.8);
      surface += vec3(0.08, 0.25, 0.65) * rim * smoothstep(-0.08, 0.25, sunHeight) * 0.30;
    }
    gl_FragColor = vec4(linearToSrgb(surface), 1.0);
  }
`;

export const atmosphereVertexShader = /* glsl */ `
  varying vec3 vEarthNormal;
  varying vec3 vViewNormal;
  void main() {
    vEarthNormal = normal;
    vViewNormal = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

export const atmosphereFragmentShader = /* glsl */ `
  precision highp float;
  uniform vec3 sunDirection;
  varying vec3 vEarthNormal;
  varying vec3 vViewNormal;
  void main() {
    float sunHeight = dot(normalize(vEarthNormal), normalize(sunDirection));
    float intensity = pow(max(0.0, 0.64 - abs(normalize(vViewNormal).z)), 3.5);
    float sunlit = smoothstep(-0.10, 0.25, sunHeight);
    gl_FragColor = vec4(0.23, 0.46, 1.0, intensity * sunlit * 0.65);
  }
`;
