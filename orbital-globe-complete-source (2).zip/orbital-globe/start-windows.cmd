@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is required. Install Node.js, then open this file again.
  pause
  exit /b 1
)
node server.mjs
pause
