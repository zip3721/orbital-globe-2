# 第三方与来源说明

## 原始页面

原始页面及其静态资源来自 https://hqman.me/demo/gpt-6-astra-3d-globe/ 。

本包保留原始内容、模型署名、canonical 地址和依赖文件中的版权声明。此整理包不为原站页面、设计、纹理或其他素材追加许可证，也不宣称这些内容属于公有领域。

## 上游依赖

版本通过下载文件中的版本字符串确认。许可证文本从以下上游地址获取，保存在 `licenses/`：

| 依赖                        | 版本               | 许可证文件                | 上游来源                                                                   |
| --------------------------- | ------------------ | ------------------------- | -------------------------------------------------------------------------- |
| React / ReactDOM            | 18.3.1             | `react-LICENSE.txt`       | https://raw.githubusercontent.com/facebook/react/v18.3.1/LICENSE           |
| Three.js                    | r160               | `three-LICENSE.txt`       | https://raw.githubusercontent.com/mrdoob/three.js/r160/LICENSE             |
| Tailwind CSS browser bundle | 4.1.12             | `tailwindcss-LICENSE.txt` | https://raw.githubusercontent.com/tailwindlabs/tailwindcss/v4.1.12/LICENSE |
| Manrope                     | 字体元数据为 4.504 | `manrope-OFL.txt`         | https://raw.githubusercontent.com/google/fonts/main/ofl/manrope/OFL.txt    |

ReactDOM 文件还保留其嵌入的 Modernizr 声明；各依赖原有版权注释保持原样。

三张地球纹理是目标页面实际引用的本地文件。本次提取没有确定其更早的来源或独立授权，未为它们附加推测的许可证。

## 航空数据

机场和跑道数据来自 OurAirports 官方仓库：https://github.com/davidmegginson/ourairports-data ，数据下载和公开领域说明见 https://ourairports.com/data/ 。文件在本包中经过格式化、过滤和字段精简。

内置航线只收录具名航空公司公开页面中的航班号、机型和起终点等事实，逐条来源在 `data/flights.seed.json` 中；不包含完整网页、文章或受限数据库。

AirLabs 的实时数据、航线库及自行导入的数据属于各自数据源，使用者应遵循其账户与数据授权条款。本包没有嵌入第三方 API 密钥或授权凭证。
