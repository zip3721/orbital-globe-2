import * as THREE from "./assets/three.module.js";
import { getSolarState } from "./solar.js";
import { AviationPanel } from "./aviation-ui.js";
import {
  MIN_ZOOM,
  MAX_ZOOM,
  clampZoom,
  scaleZoom,
  orientationAt,
  northUpOrientation,
  cameraDepth,
} from "./globe-navigation.js";
import {
  greatCirclePath,
  greatCirclePoint,
  splitDateLine,
  estimateFlightPosition,
} from "./aviation-core.js";
import {
  surfaceVertexShader,
  surfaceFragmentShader,
  atmosphereVertexShader,
  atmosphereFragmentShader,
} from "./earth-shaders.js";
const { createElement: h, useState, useEffect, useRef } = React;
const paths = {
  globe:
    "M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM3.8 8.5 8 9l2 3-1 3 3 2 1 3m7-12-5 1-2-3 2-2m5 9-4-1-2 3 2 3",
  box: "m12 3 9 5-9 5-9-5 9-5Zm-9 5v10l9 5 9-5V8m-9 5v10M7.5 5.5l9 5",
  chart: "M12 3v9h9A9 9 0 0 0 12 3Zm-3 1a9 9 0 1 0 11 11H9V4Z",
  user: "M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0ZM5 21v-2a7 7 0 0 1 14 0v2H5Z",
  settings:
    "m9 3-1 3-3 1-2 4 2 3v3l4 3 3-1 3 1 4-3v-3l2-3-2-4-3-1-1-3H9Zm6 9a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",
  logout: "M14 4H4v16h10m-3-8h10m-4-4 4 4-4 4",
  moon: "M20.5 13A8.8 8.8 0 0 1 11 3.5 9 9 0 1 0 20.5 13Z",
  sun: "M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm-4-10v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5",
  bell: "M6 9a6 6 0 0 1 12 0v5l2 3H4l2-3V9Zm4 11h4",
  chevron: "m6 9 6 6 6-6",
  up: "m6 15 6-6 6 6",
  plus: "M12 5v14M5 12h14",
  minus: "M5 12h14",
  reset: "M8 3v5H3m13-5v5h5M8 21v-5H3m13 5v-5h5",
  north: "M12 3v18M7 8l5-5 5 5M7 16l5 5 5-5",
  layers: "m12 3 10 6-10 6L2 9l10-6ZM2 13l10 6 10-6M2 17l10 6 10-6",
  plane: "m21 16-8-5V4c0-3-3-3-3 0v7l-8 5v2l8-2v4l-3 2h9l-3-2v-4l8 2v-2Z",
  ship: "M7 8V5h10v3m-5-6v3M4 11l8-3 8 3-2 7H6l-2-7Zm-2 9 3 1 4-1 3 1 3-1 4 1 3-1",
  truck:
    "M3 5h11v12H3V5Zm11 5h4l3 4v3h-7m-6 1a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm11 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z",
  trend: "m3 17 6-6 4 3 7-9m-6 0h6v6",
  search: "M16 10a6 6 0 1 1-12 0 6 6 0 0 1 12 0Zm-2 5 6 6",
  filter: "M3 7h18M3 17h18M8 4v6m8 4v6",
  more: "M12 4v1m0 6v1m0 6v1",
  close: "m6 6 12 12M6 18 18 6",
  check: "m5 12 4 4L19 6",
};
function Icon({ name, size = 20, fill = false, ...props }) {
  return h(
    "svg",
    {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: fill ? "currentColor" : "none",
      stroke: fill ? "none" : "currentColor",
      strokeWidth: 1.7,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": true,
      ...props,
    },
    h("path", { d: paths[name] || paths.globe }),
  );
}
const cargoes = [
  {
    id: "AA-845",
    icon: "plane",
    from: "USA",
    to: "COL",
    distance: "3780",
    date: "Jun 5, 2024",
    status: "Pending",
    progress: "60%",
    lat: 15,
    lon: -108,
    start: [49, -124],
    end: [10, -75],
    risk: 10,
  },
  {
    id: "JL-748",
    icon: "ship",
    from: "CHN",
    to: "KOR",
    distance: "620",
    date: "Jun 3, 2024",
    status: "Pending",
    progress: "72%",
    lat: 35,
    lon: -64,
    start: [31, 121],
    end: [36, 127],
    risk: 8,
  },
  {
    id: "MU-131",
    icon: "plane",
    from: "JPN",
    to: "DEU",
    distance: "5875",
    date: "Apr 25, 2024",
    status: "Arrived",
    progress: "37%",
    lat: 0,
    lon: -139,
    start: [36, 140],
    end: [51, 10],
    risk: 4,
  },
  {
    id: "ML-356",
    icon: "truck",
    from: "BRA",
    to: "ARG",
    distance: "1430",
    date: "Jun 7, 2024",
    status: "Pending",
    progress: "45%",
    lat: -8,
    lon: -51,
    start: [-23, -46],
    end: [-34, -58],
    risk: 12,
  },
];
const geo = (lat, lon, r = 1) => {
  const a = (lat * Math.PI) / 180,
    b = (lon * Math.PI) / 180;
  return new THREE.Vector3(
    Math.cos(a) * Math.cos(b) * r,
    Math.sin(a) * r,
    -Math.cos(a) * Math.sin(b) * r,
  );
};

function Globe({
  api,
  onReady,
  onPosition,
  selected,
  onSelect,
  mode,
  motion,
  aviationEnabled,
  aviationSelection,
}) {
  const container = useRef(null),
    markers = useRef({}),
    settings = useRef({
      selected,
      mode,
      motion,
      onPosition,
      onSelect,
      aviationEnabled,
      aviationSelection,
    });
  settings.current = {
    selected,
    mode,
    motion,
    onPosition,
    onSelect,
    aviationEnabled,
    aviationSelection,
  };
  useEffect(() => {
    const host = container.current;
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true,
        powerPreference: "high-performance",
      });
    } catch (e) {
      onReady("WebGL is unavailable. Enable hardware acceleration and reload.");
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0, 0);
    host.prepend(renderer.domElement);
    const scene = new THREE.Scene(),
      camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 3000);
    camera.position.z = 1500;
    const group = new THREE.Group();
    scene.add(group);
    const initial = new THREE.Quaternion().setFromUnitVectors(
      geo(0, -98),
      new THREE.Vector3(0, 0, 1),
    );
    group.quaternion.copy(initial);
    const geometry = new THREE.SphereGeometry(1, 128, 96),
      loader = new THREE.TextureLoader();
    let stopped = false,
      frame,
      ready = false,
      loaded = 0;
    const textures = [
      "earth-day.jpg",
      "earth-lights.jpg",
      "earth-clouds-hd.jpg",
    ].map((file) =>
      loader.load(
        "./assets/" + file,
        () => {
          loaded++;
          if (loaded === 3 && !stopped) {
            ready = true;
            onReady(true);
          }
        },
        undefined,
        () => onReady("Earth textures could not load. Please reload the page."),
      ),
    );
    textures.forEach((t) => {
      t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    });
    let solarState = getSolarState();
    let lastSolarSecond = Math.floor(solarState.timestamp / 1000);
    // Share the same live Sun and cloud animation between both map views.
    const sunUniform = { value: new THREE.Vector3(...solarState.direction) };
    const cloudUniform = { value: 0 };
    const sharedSurfaceUniforms = {
      dayMap: { value: textures[0] },
      nightMap: { value: textures[1] },
      cloudMap: { value: textures[2] },
      sunDirection: sunUniform,
      cloudOffset: cloudUniform,
    };
    const makeSurfaceMaterial = (flat) =>
      new THREE.ShaderMaterial({
        uniforms: {
          ...sharedSurfaceUniforms,
          flatMap: { value: flat ? 1 : 0 },
        },
        vertexShader: surfaceVertexShader,
        fragmentShader: surfaceFragmentShader,
      });
    const material = makeSurfaceMaterial(false);
    const earth = new THREE.Mesh(geometry, material);
    group.add(earth);
    const atmosphere = new THREE.Mesh(
      new THREE.SphereGeometry(1.012, 96, 64),
      new THREE.ShaderMaterial({
        transparent: true,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        uniforms: { sunDirection: sunUniform },
        vertexShader: atmosphereVertexShader,
        fragmentShader: atmosphereFragmentShader,
      }),
    );
    group.add(atmosphere);
    const mapGroup = new THREE.Group();
    mapGroup.visible = false;
    scene.add(mapGroup);
    const map = new THREE.Mesh(
      new THREE.PlaneGeometry(3.15, 1.575),
      makeSurfaceMaterial(true),
    );
    mapGroup.add(map);
    const routeGroup = new THREE.Group();
    group.add(routeGroup);
    const mapRouteGroup = new THREE.Group();
    mapGroup.add(mapRouteGroup);
    let routeId = null,
      routePoints = [],
      mapRoutePoints = [],
      bead,
      flatBead;
    const mapPoint = (lat, lon) =>
      new THREE.Vector3((lon / 180) * 1.575, (lat / 90) * 0.7875, 0.02);
    function clearRoutes(g) {
      while (g.children.length) {
        const o = g.children[0];
        g.remove(o);
        o.geometry?.dispose();
        o.material?.dispose();
      }
    }
    function makeRoute(c) {
      clearRoutes(routeGroup);
      clearRoutes(mapRouteGroup);
      const start = geo(...c.start),
        end = geo(...c.end),
        mid =
          c.id === "AA-845"
            ? geo(c.lat, c.lon)
            : start.clone().lerp(end, 0.5).normalize();
      const parts = [
        [start, mid, 0xffda25],
        [mid, end, 0xffffff],
      ];
      routePoints = [];
      mapRoutePoints = [];
      parts.forEach(([a, b, color], j) => {
        const points = [];
        for (let i = 0; i <= 90; i++) {
          const t = i / 90;
          let p = a.clone().lerp(b, t);
          if (c.id === "AA-845" && j === 0) {
            const bend = geo(34, -140);
            p = a
              .clone()
              .multiplyScalar((1 - t) * (1 - t))
              .add(bend.multiplyScalar(2 * (1 - t) * t))
              .add(b.clone().multiplyScalar(t * t));
          }
          points.push(
            p.normalize().multiplyScalar(1.014 + Math.sin(t * Math.PI) * 0.025),
          );
        }
        routePoints.push(...points);
        routeGroup.add(
          new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(points),
            new THREE.LineBasicMaterial({
              color,
              transparent: true,
              opacity: 0.95,
            }),
          ),
        );
      });
      const a = mapPoint(...c.start),
        b = mapPoint(...c.end);
      for (let i = 0; i <= 100; i++) {
        const t = i / 100;
        const p = a.clone().lerp(b, t);
        p.y += Math.sin(t * Math.PI) * 0.18;
        mapRoutePoints.push(p);
      }
      mapRouteGroup.add(
        new THREE.Line(
          new THREE.BufferGeometry().setFromPoints(mapRoutePoints),
          new THREE.LineBasicMaterial({ color: 0xffda25 }),
        ),
      );
      bead = new THREE.Mesh(
        new THREE.SphereGeometry(0.005, 12, 8),
        new THREE.MeshBasicMaterial({ color: 0xffffff }),
      );
      routeGroup.add(bead);
      flatBead = new THREE.Mesh(
        new THREE.CircleGeometry(0.006, 12),
        new THREE.MeshBasicMaterial({ color: 0xffda25 }),
      );
      mapRouteGroup.add(flatBead);
      routeId = c.id;
    }
    const passengerRoutes = new THREE.Group();
    const passengerMapRoutes = new THREE.Group();
    group.add(passengerRoutes);
    mapGroup.add(passengerMapRoutes);
    let passengerKey = null,
      passengerPlane = null,
      passengerFlatPlane = null;
    const focusTarget = initial.clone();
    const mapFocus = new THREE.Vector3(),
      targetMapFocus = new THREE.Vector3();
    function focus(lat, lon, zoomLevel = 0.95) {
      focusTarget.copy(orientationAt(lat, lon));
      targetMapFocus.copy(mapPoint(lat, lon)).setZ(0);
      resetting = true;
      targetZoom = clampZoom(zoomLevel);
      vx = vy = 0;
      settings.current.onPosition([lat, lon]);
    }
    function passengerRoute(selection) {
      clearRoutes(passengerRoutes);
      clearRoutes(passengerMapRoutes);
      passengerPlane = null;
      passengerFlatPlane = null;
      if (!selection) return;
      if (selection.kind === "airport") {
        focus(selection.airport.lat, selection.airport.lon, 1.05);
        return;
      }
      const flight = selection.flight;
      if (!flight.origin || !flight.destination) return;
      const from = [flight.origin.lat, flight.origin.lon],
        to = [flight.destination.lat, flight.destination.lon];
      const path = greatCirclePath(from, to);
      const points = path.map((point, i) =>
        geo(
          ...point,
          1.018 + Math.sin((i / (path.length - 1)) * Math.PI) * 0.025,
        ),
      );
      passengerRoutes.add(
        new THREE.Line(
          new THREE.BufferGeometry().setFromPoints(points),
          new THREE.LineBasicMaterial({
            color: 0xffda25,
            transparent: true,
            opacity: 0.95,
          }),
        ),
      );
      for (const segment of splitDateLine(path)) {
        if (segment.length > 1)
          passengerMapRoutes.add(
            new THREE.Line(
              new THREE.BufferGeometry().setFromPoints(
                segment.map((p) => mapPoint(...p)),
              ),
              new THREE.LineBasicMaterial({ color: 0xffda25 }),
            ),
          );
      }
      passengerPlane = new THREE.Mesh(
        new THREE.SphereGeometry(0.008, 12, 8),
        new THREE.MeshBasicMaterial({ color: 0xfff5bb }),
      );
      passengerFlatPlane = new THREE.Mesh(
        new THREE.CircleGeometry(0.008, 12),
        new THREE.MeshBasicMaterial({ color: 0xffda25 }),
      );
      passengerRoutes.add(passengerPlane);
      passengerMapRoutes.add(passengerFlatPlane);
      focus(...greatCirclePoint(from, to, 0.5), 0.88);
    }
    function updatePassenger(selection, wallTime) {
      for (const id of [
        "aviation-airport",
        "aviation-origin",
        "aviation-destination",
        "aviation-plane",
      ])
        if (markers.current[id]) markers.current[id].style.display = "none";
      if (passengerPlane) passengerPlane.visible = false;
      if (passengerFlatPlane) passengerFlatPlane.visible = false;
      const marker = (id, coords, r) => {
        if (markers.current[id]) {
          markers.current[id].style.display = "flex";
          positionMarker(id, ...coords, r);
        }
      };
      if (!selection) return;
      if (selection.kind === "airport") {
        marker("aviation-airport", [
          selection.airport.lat,
          selection.airport.lon,
        ]);
        return;
      }
      const f = selection.flight;
      if (f.origin) marker("aviation-origin", [f.origin.lat, f.origin.lon]);
      if (f.destination)
        marker("aviation-destination", [f.destination.lat, f.destination.lon]);
      const estimate = estimateFlightPosition(f, wallTime);
      if (estimate.position && passengerPlane) {
        const height =
          1.018 + Math.sin((estimate.progress || 0) * Math.PI) * 0.025;
        passengerPlane.position.copy(geo(...estimate.position, height));
        passengerPlane.visible = true;
        passengerFlatPlane.position.copy(mapPoint(...estimate.position));
        passengerFlatPlane.visible = true;
        marker("aviation-plane", estimate.position, height + 0.01);
        const tag =
          markers.current["aviation-plane"]?.querySelector(".marker-tag");
        if (tag)
          tag.textContent =
            f.number +
            (estimate.kind === "estimated"
              ? " · 估算"
              : estimate.kind === "arrived"
                ? " · 已到达"
                : " · 待起飞");
      }
    }
    let W = 0,
      H = 0,
      radius = 0,
      cx = 0,
      cy = 0,
      zoom = 1,
      targetZoom = 1,
      resetting = false,
      dragging = false,
      lastX = 0,
      lastY = 0,
      lastMove = 0,
      vx = 0,
      vy = 0,
      activeMode = "3d",
      lastTime = 0,
      lastCoords = 0;
    const pointers = new Map();
    let pinchDistance = 0;
    function resize() {
      W = host.clientWidth;
      H = host.clientHeight;
      renderer.setSize(W, H);
      camera.left = -W / 2;
      camera.right = W / 2;
      camera.top = H / 2;
      camera.bottom = -H / 2;
      radius = Math.min(W * 0.3, H * 0.475);
      cx = W * 0.5;
      cy = H * 0.04 + radius;
      if (W < 620) {
        radius = W * 0.57;
        cy = H * 0.59;
      }
      const depth = cameraDepth(radius);
      camera.position.z = depth.z;
      camera.far = depth.far;
      camera.updateProjectionMatrix();
    }
    const observer = new ResizeObserver(resize);
    observer.observe(host);
    resize();
    function reset() {
      focusTarget.copy(initial);
      resetting = true;
      targetZoom = 1;
      targetMapFocus.set(0, 0, 0);
      vx = vy = 0;
    }
    function northUp() {
      focusTarget.copy(northUpOrientation(group.quaternion));
      resetting = true;
      vx = vy = 0;
    }
    function centerFlight() {
      const selection = settings.current.aviationSelection;
      if (!settings.current.aviationEnabled || selection?.kind !== "flight")
        return { reason: "请先搜索并选择一个航班。" };
      const estimate = estimateFlightPosition(selection.flight, Date.now());
      if (!estimate.position) return { reason: estimate.reason };
      focus(...estimate.position, targetZoom);
      return estimate;
    }
    api.current = {
      zoom: (delta) => {
        targetZoom = scaleZoom(targetZoom, delta);
      },
      reset,
      focus,
      northUp,
      centerFlight,
      getState: () => ({
        rotation: group.quaternion.toArray(),
        zoom,
        zoomLimits: [MIN_ZOOM, MAX_ZOOM],
        mode: activeMode,
        ready,
        renderer: "Three.js WebGL",
        vertices: geometry.attributes.position.count,
        solar: { ...solarState, direction: [...solarState.direction] },
      }),
    };
    function down(e) {
      if (e.button !== 0 && e.pointerType !== "touch") return;
      host.focus({ preventScroll: true });
      host.setPointerCapture(e.pointerId);
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      dragging = true;
      resetting = false;
      vx = vy = 0;
      lastX = e.clientX;
      lastY = e.clientY;
      lastMove = performance.now();
      if (pointers.size === 2) {
        const p = [...pointers.values()];
        pinchDistance = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
      }
    }
    function move(e) {
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pointers.size === 2) {
        const p = [...pointers.values()],
          d = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
        targetZoom = clampZoom((targetZoom * d) / Math.max(pinchDistance, 1));
        pinchDistance = d;
        return;
      }
      if (!dragging) return;
      const dx = e.clientX - lastX,
        dy = e.clientY - lastY;
      if (activeMode === "2d") {
        const scale = Math.max(radius * zoom * 0.85, 1);
        targetMapFocus.x = THREE.MathUtils.clamp(
          targetMapFocus.x - dx / scale,
          -1.575,
          1.575,
        );
        targetMapFocus.y = THREE.MathUtils.clamp(
          targetMapFocus.y + dy / scale,
          -0.7875,
          0.7875,
        );
        mapFocus.copy(targetMapFocus);
        settings.current.onPosition([
          (mapFocus.y / 0.7875) * 90,
          (mapFocus.x / 1.575) * 180,
        ]);
      } else {
        vx = (dx * 0.0036) / Math.max(1, zoom);
        vy = (dy * 0.0036) / Math.max(1, zoom);
        group.quaternion.premultiply(
          new THREE.Quaternion().setFromEuler(
            new THREE.Euler(vy, vx, 0, "XYZ"),
          ),
        );
      }
      lastX = e.clientX;
      lastY = e.clientY;
      lastMove = performance.now();
    }
    function up(e) {
      pointers.delete(e.pointerId);
      dragging = pointers.size > 0;
      if (dragging) {
        const p = [...pointers.values()][0];
        lastX = p.x;
        lastY = p.y;
      }
      if (performance.now() - lastMove > 100 || !settings.current.motion)
        vx = vy = 0;
    }
    function wheel(e) {
      e.preventDefault();
      const pixels =
        e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? H : 1);
      targetZoom = scaleZoom(
        targetZoom,
        THREE.MathUtils.clamp(-pixels * 0.001, -0.5, 0.5),
      );
    }
    function key(e) {
      const rotations = {
        ArrowLeft: [0, -0.1],
        ArrowRight: [0, 0.1],
        ArrowUp: [-0.1, 0],
        ArrowDown: [0.1, 0],
      };
      if (rotations[e.key] && activeMode === "3d") {
        e.preventDefault();
        resetting = false;
        const [x, y] = rotations[e.key];
        group.quaternion.premultiply(
          new THREE.Quaternion().setFromEuler(
            new THREE.Euler(x / Math.max(1, zoom), y / Math.max(1, zoom), 0),
          ),
        );
      }
      if (e.key === "+" || e.key === "=") api.current.zoom(0.1);
      if (e.key === "-") api.current.zoom(-0.1);
      if (e.key.toLowerCase() === "n") northUp();
      if (e.key === "Home") {
        e.preventDefault();
        reset();
      }
    }
    host.addEventListener("pointerdown", down);
    host.addEventListener("pointermove", move);
    host.addEventListener("pointerup", up);
    host.addEventListener("pointercancel", up);
    host.addEventListener("wheel", wheel, { passive: false });
    host.addEventListener("keydown", key);
    const project = new THREE.Vector3(),
      world = new THREE.Vector3(),
      q = new THREE.Quaternion();
    function positionMarker(id, lat, lon, height = 1.024) {
      const element = markers.current[id];
      if (!element) return;
      const flat = activeMode === "2d";
      world.copy(flat ? mapPoint(lat, lon) : geo(lat, lon, height));
      if (!flat) {
        world.applyQuaternion(group.quaternion);
        element.style.opacity = world.z > 0.07 ? "1" : "0";
        element.style.pointerEvents = world.z > 0.07 ? "" : "none";
        world.multiplyScalar(radius * zoom).add(group.position);
      } else {
        element.style.opacity = "1";
        element.style.pointerEvents = "";
        world.multiplyScalar(radius * zoom * 0.85).add(mapGroup.position);
      }
      project.copy(world).project(camera);
      const x = (project.x * 0.5 + 0.5) * W,
        y = (-project.y * 0.5 + 0.5) * H;
      element.style.transform = `translate3d(${x}px,${y}px,0) translate(-50%,-100%)`;
    }
    function animate(now) {
      if (stopped) return;
      frame = requestAnimationFrame(animate);
      if (document.hidden) return;
      const dt = Math.min((now - lastTime) / 16.667, 2) || 1;
      lastTime = now;
      const s = settings.current;
      if (s.mode !== activeMode) {
        activeMode = s.mode;
        group.visible = s.mode === "3d";
        mapGroup.visible = s.mode === "2d";
        vx = vy = 0;
      }
      if (routeId !== s.selected)
        makeRoute(cargoes.find((c) => c.id === s.selected));
      zoom = THREE.MathUtils.lerp(
        zoom,
        targetZoom,
        s.motion ? 1 - Math.pow(0.87, dt) : 1,
      );
      if (resetting) {
        group.quaternion.slerp(
          focusTarget,
          s.motion ? 1 - Math.pow(0.91, dt) : 1,
        );
        if (group.quaternion.angleTo(focusTarget) < 0.001) resetting = false;
      } else if (!dragging && s.motion) {
        vx *= Math.pow(0.94, dt);
        vy *= Math.pow(0.94, dt);
        if (Math.abs(vx) + Math.abs(vy) > 0.00001)
          group.quaternion.premultiply(
            q.setFromEuler(new THREE.Euler(vy * dt, vx * dt, 0, "XYZ")),
          );
      }
      group.scale.setScalar(radius * zoom);
      const displayCx = s.aviationEnabled && W > 900 ? W * 0.63 : cx;
      const displayCy = s.aviationEnabled && W < 620 ? H * 0.32 : cy;
      group.position.set(displayCx - W / 2, H / 2 - displayCy, 0);
      mapGroup.scale.setScalar(radius * zoom * 0.85);
      mapFocus.lerp(targetMapFocus, s.motion ? 1 - Math.pow(0.87, dt) : 1);
      mapGroup.position.set(
        (s.aviationEnabled && W > 900 ? W * 0.12 : 0) -
          mapFocus.x * radius * zoom * 0.85,
        (s.aviationEnabled && W < 620 ? H * 0.18 : -H * 0.05) -
          mapFocus.y * radius * zoom * 0.85,
        0,
      );
      // Wall-clock UTC, not elapsed animation time; resume correctly after sleep.
      // Motion preference and interface theme do not freeze or override daylight.
      const wallTime = Date.now();
      const solarSecond = Math.floor(wallTime / 1000);
      if (solarSecond !== lastSolarSecond) {
        solarState = getSolarState(wallTime);
        sunUniform.value.fromArray(solarState.direction);
        lastSolarSecond = solarSecond;
      }
      if (s.motion)
        cloudUniform.value = (cloudUniform.value + 0.00000008 * dt) % 1;
      const step = s.motion ? (now * 0.000055) % 1 : 0.4;
      if (bead && routePoints.length)
        bead.position.copy(
          routePoints[Math.floor(step * (routePoints.length - 1))],
        );
      if (flatBead && mapRoutePoints.length)
        flatBead.position.copy(
          mapRoutePoints[Math.floor(step * (mapRoutePoints.length - 1))],
        );
      const c = cargoes.find((c) => c.id === s.selected);
      positionMarker("origin", ...c.start);
      positionMarker("destination", ...c.end);
      cargoes.forEach((c) => positionMarker(c.id, c.lat, c.lon));
      if (
        now - lastCoords > 150 &&
        activeMode === "3d" &&
        (dragging || Math.abs(vx) + Math.abs(vy) > 0.001)
      ) {
        const center = new THREE.Vector3(0, 0, 1).applyQuaternion(
          group.quaternion.clone().invert(),
        );
        s.onPosition([
          THREE.MathUtils.radToDeg(Math.asin(center.y)),
          THREE.MathUtils.radToDeg(Math.atan2(-center.z, center.x)),
        ]);
        lastCoords = now;
      }
      routeGroup.visible = !s.aviationEnabled;
      mapRouteGroup.visible = !s.aviationEnabled;
      passengerRoutes.visible = s.aviationEnabled;
      passengerMapRoutes.visible = s.aviationEnabled;
      const selectedAviation = s.aviationEnabled ? s.aviationSelection : null;
      const nextKey = selectedAviation
        ? selectedAviation.kind +
          ":" +
          (selectedAviation.airport?.id || selectedAviation.flight?.id)
        : null;
      if (nextKey !== passengerKey) {
        passengerRoute(selectedAviation);
        passengerKey = nextKey;
      }
      updatePassenger(selectedAviation, wallTime);
      renderer.render(scene, camera);
    }
    frame = requestAnimationFrame(animate);
    return () => {
      stopped = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      [
        "pointerdown",
        "pointermove",
        "pointerup",
        "pointercancel",
        "wheel",
        "keydown",
      ].forEach((name, i) =>
        host.removeEventListener(name, [down, move, up, up, wheel, key][i]),
      );
      scene.traverse((o) => {
        o.geometry?.dispose();
        o.material?.dispose();
      });
      textures.forEach((t) => t.dispose());
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);
  const c = cargoes.find((c) => c.id === selected);
  return h(
    React.Fragment,
    null,
    h("div", {
      className: "globe-stage",
      ref: container,
      tabIndex: 0,
      role: "application",
      "aria-label":
        "Interactive 3D Earth. Drag to rotate or pan, scroll to zoom up to 8x. Arrow keys rotate; N restores north-up; Home resets.",
    }),
    h(
      "div",
      {
        className: "marker-layer",
        "aria-label": "Cargo locations",
        style: { display: aviationEnabled ? "none" : undefined },
      },
      ...[
        ["origin", c.from],
        ["destination", c.to],
      ].map(([id, label]) =>
        h(
          "div",
          {
            className: "marker " + id,
            key: id,
            ref: (el) => (markers.current[id] = el),
          },
          h("span", { className: "marker-tag" }, label),
          h("span", { className: "location-point" }),
        ),
      ),
      ...cargoes.map((c) =>
        h(
          "div",
          {
            className: "marker",
            key: c.id,
            ref: (el) => (markers.current[c.id] = el),
          },
          h(
            "button",
            {
              className:
                "cargo-marker " + (selected === c.id ? "selected" : ""),
              onClick: () => onSelect(c.id),
              "aria-label": `Track ${c.id}, ${c.from} to ${c.to}`,
              "aria-pressed": selected === c.id,
            },
            h("span", { className: "marker-tag" }, c.id),
            h(
              "span",
              { className: "marker-disc" },
              h(Icon, { name: c.icon, fill: c.icon === "plane", size: 18 }),
            ),
          ),
        ),
      ),
    ),
    h(
      "div",
      {
        className: "marker-layer",
        "aria-label": "Airport and passenger flight locations",
        style: { display: aviationEnabled ? undefined : "none" },
      },
      ...[
        [
          "aviation-airport",
          aviationSelection?.airport?.iata ||
            aviationSelection?.airport?.icao ||
            aviationSelection?.airport?.id ||
            "机场",
        ],
        ["aviation-origin", aviationSelection?.flight?.originCode || "出发"],
        [
          "aviation-destination",
          aviationSelection?.flight?.destinationCode || "到达",
        ],
      ].map(([id, label]) =>
        h(
          "div",
          {
            key: id,
            className: "marker aviation-marker",
            ref: (el) => (markers.current[id] = el),
          },
          h("span", { className: "marker-tag" }, label),
          h("span", { className: "location-point" }),
        ),
      ),
      h(
        "div",
        {
          className: "marker aviation-plane",
          ref: (el) => (markers.current["aviation-plane"] = el),
        },
        h(
          "div",
          { className: "cargo-marker" },
          h("span", { className: "marker-tag" }, "估算位置"),
          h(
            "span",
            { className: "marker-disc" },
            h(Icon, { name: "plane", fill: true, size: 21 }),
          ),
        ),
      ),
    ),
  );
}

function App() {
  const [aviationOpen, setAviationOpen] = useState(true),
    [aviationSelection, setAviationSelection] = useState(null),
    [open, setOpen] = useState(false),
    [selected, setSelected] = useState("AA-845"),
    [mode, setMode] = useState("3d"),
    [lightTheme, setLightTheme] = useState(false),
    [ready, setReady] = useState(false),
    [position, setPosition] = useState([5.403478, -77.399377]),
    [query, setQuery] = useState(""),
    [pending, setPending] = useState(false),
    [popover, setPopover] = useState(null),
    [modal, setModal] = useState(null),
    [motion, setMotion] = useState(
      !matchMedia("(prefers-reduced-motion: reduce)").matches,
    ),
    [toast, setToast] = useState("");
  const globe = useRef(null),
    toastTimer = useRef(null),
    handle = useRef(null),
    modalRef = useRef(null);
  const c = cargoes.find((c) => c.id === selected);
  const notify = (message) => {
    clearTimeout(toastTimer.current);
    setToast(message);
    toastTimer.current = setTimeout(() => setToast(""), 3000);
  };
  const togglePopover = (name) => setPopover((p) => (p === name ? null : name));
  const focusAviation = (selection = aviationSelection) => {
    if (selection?.kind === "airport")
      globe.current?.focus(selection.airport.lat, selection.airport.lon, 1.05);
    else if (selection?.flight?.origin && selection.flight.destination) {
      const f = selection.flight;
      globe.current?.focus(
        ...greatCirclePoint(
          [f.origin.lat, f.origin.lon],
          [f.destination.lat, f.destination.lon],
          0.5,
        ),
        0.88,
      );
    }
  };
  const selectAviation = (selection, focus = true) => {
    setAviationSelection(selection);
    if (focus) focusAviation(selection);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") {
        if (modal) setModal(null);
        else if (popover) setPopover(null);
        else if (open) {
          setOpen(false);
          handle.current?.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [modal, popover, open]);
  useEffect(() => {
    if (!modal) return;
    const previous = document.activeElement,
      el = modalRef.current;
    const focusables = () => [
      ...el.querySelectorAll("button,[href],input,[tabindex='0']"),
    ];
    focusables()[0]?.focus();
    const trap = (e) => {
      if (e.key !== "Tab") return;
      const list = focusables(),
        first = list[0],
        last = list.at(-1);
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    el.addEventListener("keydown", trap);
    return () => {
      el.removeEventListener("keydown", trap);
      previous?.focus();
    };
  }, [modal]);
  useEffect(() => () => clearTimeout(toastTimer.current), []);
  const choose = (id) => {
    setSelected(id);
  };
  const filtered = cargoes.filter(
    (c) =>
      (!pending || c.status === "Pending") &&
      `${c.id} ${c.from} ${c.to} ${c.status}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  const nav = (name, label, action, active = false, dot = false) =>
    h(
      "button",
      {
        className: "nav-button " + (active ? "active" : ""),
        onClick: action,
        "aria-label": label,
        title: label,
      },
      h(Icon, {
        name,
        size: 21,
        fill: ["user", "chart", "settings"].includes(name),
      }),
      dot && h("span", { className: "dot" }),
    );
  return h(
    "main",
    {
      className:
        "dashboard " +
        (lightTheme ? "dawn" : "") +
        (aviationOpen ? " aviation-active" : ""),
      "aria-label": "Global logistics dashboard",
    },
    h(
      "aside",
      { className: "sidebar", "aria-label": "Main navigation" },
      h(
        "button",
        {
          className: "brand",
          title: "Reset global view",
          "aria-label": "Orbital, reset global view",
          onClick: () => {
            globe.current?.reset();
            setMode("3d");
            setOpen(false);
            setPopover(null);
          },
        },
        h(
          "svg",
          { viewBox: "0 0 44 44", width: 40, height: 40, "aria-hidden": true },
          h("path", { d: "M13 5h15l14 13-14 13H13l14-13Z", fill: "#fff" }),
          h("path", { d: "M2 17h14l13 12-13 12H2l13-12Z", fill: "#ffda25" }),
        ),
      ),
      h(
        "nav",
        { className: "nav-items" },
        nav(
          "plane",
          "机场与客运航班",
          () => {
            setAviationOpen(true);
            setOpen(false);
            setPopover(null);
          },
          aviationOpen,
        ),
        nav(
          "globe",
          "Global view",
          () => {
            setAviationOpen(false);
            setOpen(false);
            setPopover(null);
            setModal(null);
          },
          !open && !aviationOpen,
        ),
        nav(
          "box",
          "Cargo activities",
          () => {
            setAviationOpen(false);
            setOpen((v) => !v);
            setPopover(null);
          },
          open,
          true,
        ),
        nav("chart", "Delivery analytics", () => setModal("analytics")),
        nav("user", "Operations team", () => setModal("team")),
      ),
      h(
        "div",
        { className: "nav-bottom" },
        nav("settings", "Dashboard settings", () => togglePopover("settings")),
        nav("logout", "About this workspace", () => setModal("workspace")),
      ),
    ),
    h(
      "section",
      { className: "workspace " + (open ? "panel-open" : "") },
      h(Globe, {
        api: globe,
        onReady: setReady,
        onPosition: setPosition,
        selected,
        onSelect: choose,
        aviationEnabled: aviationOpen,
        aviationSelection,
        mode,
        motion,
      }),
      aviationOpen &&
        h(AviationPanel, {
          selection: aviationSelection,
          onSelect: selectAviation,
          onFocus: () => focusAviation(),
          onClose: () => setAviationOpen(false),
        }),
      ready !== true &&
        h(
          "div",
          { className: "globe-loading", role: "status" },
          !ready && h("div", { className: "loading-ring" }),
          ready || "CONNECTING TO YOUR WORLD",
        ),
      h(
        "header",
        { className: "heading" },
        h("h1", null, aviationOpen ? "Flight Explorer" : "Global View"),
        h(
          "div",
          { className: "live" },
          h("span", { className: "live-dot" }),
          h("span", null, "REAL-TIME SUNLIGHT"),

          h(
            "span",
            {
              className: "demo-badge",
              title:
                "Shipment data is illustrative. Sunlight follows your device clock.",
            },
            "DEMO",
          ),
        ),
      ),
      h(
        "div",
        { className: "topbar" },
        h(
          "div",
          {
            className: "segmented",
            "aria-label": "Interface theme; Earth sunlight follows real time",
          },
          h(
            "button",
            {
              className: !lightTheme ? "selected" : "",
              "aria-label": "Dark interface theme",
              title: "Dark interface — sunlight stays real-time",
              "aria-pressed": !lightTheme,
              onClick: () => setLightTheme(false),
            },
            h(Icon, { name: "moon", fill: true, size: 23 }),
          ),
          h(
            "button",
            {
              className: lightTheme ? "selected" : "",
              "aria-label": "Light interface theme",
              title: "Light interface — sunlight stays real-time",
              "aria-pressed": lightTheme,
              onClick: () => setLightTheme(true),
            },
            h(Icon, { name: "sun", size: 23 }),
          ),
        ),
        h(
          "div",
          { className: "top-actions" },
          h(
            "button",
            {
              className: "profile",
              "aria-label": "Open Kai's profile",
              "aria-expanded": popover === "profile",
              onClick: () => togglePopover("profile"),
            },
            h(
              "span",
              { className: "avatar" },
              h(
                "svg",
                {
                  viewBox: "0 0 40 40",
                  width: 30,
                  height: 30,
                  "aria-hidden": true,
                },
                h("rect", { width: 40, height: 40, fill: "#91aadc" }),
                h("path", { d: "M3 40q0-14 17-14t17 14", fill: "#e5e7ec" }),
                h("path", { d: "M16 24h8v8h-8", fill: "#c28d6d" }),
                h("ellipse", {
                  cx: 20,
                  cy: 17,
                  rx: 9,
                  ry: 12,
                  fill: "#d9a181",
                }),
                h("path", {
                  d: "M11 17V11q1-10 11-8 9 1 8 12l-4-7q-8 4-13 3Z",
                  fill: "#242838",
                }),
                h("path", {
                  d: "m12 19 5 4h6l5-4q0 12-8 11-7 0-8-11",
                  fill: "#3f3030",
                }),
                h("path", { d: "M17 23h6", stroke: "white", strokeWidth: 1.5 }),
              ),
            ),
            h("span", null, "Kai"),
            h(Icon, { name: "chevron", size: 16, className: "chevron" }),
          ),
          h(
            "button",
            {
              className: "notification",
              "aria-label": "Notifications",
              "aria-expanded": popover === "notifications",
              onClick: () => togglePopover("notifications"),
            },
            h(Icon, { name: "bell", fill: true, size: 20 }),
          ),
        ),
      ),
      h(
        "section",
        { className: "promo" },
        h("p", { className: "eyebrow" }, "AI-Powered"),
        h(
          "h2",
          null,
          "Plan Your",
          h("br"),
          "Route with",
          h("br"),
          "AI Now ",
          h("span", { className: "sparkles" }, "✦", h("small", null, "✦")),
        ),
        h(
          "button",
          { className: "how-link", onClick: () => setModal("how") },
          "HOW IT WORKS",
        ),
      ),
      h(
        "section",
        { className: "statistics", "aria-label": "Main statistics" },
        h("h2", null, "Main", h("br"), "Statistics"),
        ...[
          ["Monthly Delivered", "1021", "32"],
          ["Yearly Delivered", "4603", "12"],
        ].map(([label, value, growth]) =>
          h(
            "div",
            { className: "stat", key: label },
            h("div", { className: "stat-label" }, label),
            h(
              "div",
              { className: "stat-value" },
              value,
              h(
                "span",
                { className: "growth" },
                h(Icon, { name: "trend", size: 15 }),
                "+" + growth + "%",
              ),
            ),
          ),
        ),
      ),
      h(
        "div",
        { className: "coordinates", "aria-label": "View coordinates" },
        h("div", null, h("b", null, "X:"), " ", position[0].toFixed(6)),
        h("div", null, h("b", null, "Y:"), " ", position[1].toFixed(6)),
      ),
      h(
        "div",
        { className: "view-controls segmented", "aria-label": "Map view" },
        ...["3d", "2d"].map((v) =>
          h(
            "button",
            {
              className: mode === v ? "selected" : "",
              key: v,
              "aria-label": v.toUpperCase() + " view",
              "aria-pressed": mode === v,
              onClick: () => setMode(v),
            },
            h(Icon, { name: v === "3d" ? "box" : "layers", size: 20 }),
            v.toUpperCase(),
          ),
        ),
      ),
      h(
        "div",
        { className: "zoom-controls" },
        h(
          "div",
          {
            className: "globe-quick-actions",
            role: "group",
            "aria-label": "视角定位",
          },
          h(
            "button",
            {
              className: "view-action",
              disabled: ready !== true || mode === "2d",
              title:
                mode === "2d"
                  ? "平面地图始终北向朝上"
                  : "南北回正，保留中心点和缩放（N）",
              onClick: () => globe.current?.northUp(),
            },
            h(Icon, { name: "north", size: 16 }),
            "北向朝上",
          ),
          h(
            "button",
            {
              className: "view-action",
              disabled:
                ready !== true ||
                !aviationOpen ||
                aviationSelection?.kind !== "flight",
              title: "将所选航班的当前位置居中，保留缩放；空中位置为估算",
              onClick: () => {
                const result = globe.current?.centerFlight();
                notify(
                  result?.position
                    ? result.kind === "estimated"
                      ? "已居中飞机估算位置"
                      : result.reason
                    : "无法居中：" + (result?.reason || "地球尚未加载"),
                );
              },
            },
            h(Icon, { name: "plane", size: 16 }),
            "居中飞机",
          ),
        ),
        h("span", null, "Zoom"),
        h(
          "button",
          {
            className: "round-button",
            "aria-label": "Zoom in",
            onClick: () => globe.current?.zoom(0.12),
          },
          h(Icon, { name: "plus", size: 16 }),
        ),
        h(
          "button",
          {
            className: "round-button",
            "aria-label": "Zoom out",
            onClick: () => globe.current?.zoom(-0.12),
          },
          h(Icon, { name: "minus", size: 16 }),
        ),
        h(
          "button",
          {
            className: "round-button reset",
            "aria-label": "Reset globe view",
            onClick: () => {
              globe.current?.reset();
              setPosition([5.403478, -77.399377]);
            },
          },
          h(Icon, { name: "reset", size: 16 }),
        ),
      ),
      h(
        "div",
        { className: "interaction-hint" },
        mode === "3d"
          ? "Drag to explore  ·  Zoom up to 8×  ·  N: North up"
          : "Drag to pan  ·  Scroll to zoom up to 8×",
      ),
      h(
        "section",
        {
          className: "bottom-drawer " + (open ? "open" : ""),
          "aria-label": "Shipment details",
        },
        h(
          "button",
          {
            className: "drawer-handle",
            ref: handle,
            "aria-expanded": open,
            "aria-controls": "activities-content",
            onClick: () => setOpen((v) => !v),
          },
          h(Icon, { name: "up", size: 15 }),
          open ? "Hide activities" : "Activities & insights",
          h("span", { className: "drawer-count" }, "04"),
        ),
        h(
          "div",
          {
            className: "activities",
            id: "activities-content",
            inert: open ? undefined : "",
            "aria-hidden": !open,
          },
          h(
            "div",
            { className: "activities-header" },
            h("h2", null, "Activities"),
            h(
              "div",
              { className: "table-tools" },
              h(
                "label",
                { className: "search" },
                h(Icon, { name: "search", size: 17 }),
                h("input", {
                  type: "search",
                  placeholder: "Search",
                  "aria-label": "Search cargo",
                  value: query,
                  onChange: (e) => setQuery(e.target.value),
                }),
              ),
              h(
                "button",
                {
                  className: "filter-button " + (pending ? "active" : ""),
                  "aria-label": "Show pending shipments only",
                  "aria-pressed": pending,
                  onClick: () => setPending((v) => !v),
                  title: pending ? "Show all shipments" : "Show pending only",
                },
                h(Icon, { name: "filter", size: 19 }),
              ),
            ),
          ),
          h(
            "table",
            { className: "cargo-table" },
            h(
              "thead",
              null,
              h(
                "tr",
                null,
                ...[
                  "Cargo ID",
                  "Destination",
                  "Arrival date",
                  "Status",
                  "",
                ].map((label, i) => h("th", { key: i, scope: "col" }, label)),
              ),
            ),
            h(
              "tbody",
              null,
              ...filtered.map((row) =>
                h(
                  "tr",
                  {
                    key: row.id,
                    className: selected === row.id ? "selected" : "",
                    onClick: () => choose(row.id),
                  },
                  h(
                    "td",
                    null,
                    h(
                      "button",
                      {
                        className: "cargo-id bg-transparent p-0 text-left",
                        "aria-label": "Select shipment " + row.id,
                        onClick: (e) => {
                          e.stopPropagation();
                          choose(row.id);
                        },
                      },
                      h(
                        "span",
                        {
                          className:
                            "mini-cargo " +
                            (row.id === selected ? "yellow" : ""),
                        },
                        h(Icon, { name: row.icon, fill: row.icon === "plane" }),
                      ),
                      row.id,
                    ),
                  ),
                  h(
                    "td",
                    null,
                    h(
                      "div",
                      { className: "route-cells" },
                      h(
                        "div",
                        { className: "route-names" },
                        h("span", null, row.from),
                        h(
                          "span",
                          { className: "distance" },
                          row.distance + " ml",
                        ),
                        h("span", null, row.to),
                      ),
                      h(
                        "div",
                        {
                          className: "route-track",
                          style: { "--progress": row.progress },
                        },
                        h("i"),
                      ),
                    ),
                  ),
                  h("td", null, row.date),
                  h(
                    "td",
                    null,
                    h(
                      "span",
                      {
                        className:
                          "status-pill " +
                          (row.status === "Arrived" ? "arrived" : ""),
                      },
                      row.status,
                    ),
                  ),
                  h(
                    "td",
                    null,
                    h(
                      "button",
                      {
                        className: "row-more",
                        "aria-label": "Details for " + row.id,
                        onClick: (e) => {
                          e.stopPropagation();
                          choose(row.id);
                          setModal("shipment");
                        },
                      },
                      h(Icon, { name: "more", size: 17 }),
                    ),
                  ),
                ),
              ),
              !filtered.length &&
                h(
                  "tr",
                  null,
                  h(
                    "td",
                    { colSpan: 5, className: "empty-row" },
                    "No shipments match your search.",
                  ),
                ),
            ),
          ),
        ),
        h(
          "aside",
          {
            className: "risk",
            inert: open ? undefined : "",
            "aria-hidden": !open,
          },
          h(
            "div",
            { className: "risk-header" },
            h("h2", null, "Risk of Cargo Loss"),
            h(
              "button",
              { className: "details-button", onClick: () => setModal("risk") },
              "DETAILS",
            ),
          ),
          h(
            "div",
            { className: "risk-content" },
            h(
              "div",
              null,
              h("div", { className: "risk-label" }, "Loss risk"),
              h(
                "div",
                { className: "risk-value" },
                c.risk + "%",
                h(Icon, { name: "chevron", size: 20 }),
              ),
              h(
                "p",
                { className: "risk-copy" },
                "Minimal risk due",
                h("br"),
                "to good weather",
              ),
            ),
            h(
              "div",
              {
                className: "weather",
                "aria-label": "Sunny, 32 degrees Celsius",
              },
              h("div", { className: "weather-temperature" }, "32°"),
              h("div", { className: "weather-arc" }),
              h(
                "div",
                { className: "weather-sun" },
                h(Icon, { name: "sun", size: 19 }),
              ),
              h("div", { className: "weather-name" }, "Sunny"),
            ),
          ),
        ),
      ),
    ),
    popover &&
      h(
        "div",
        { className: "popover " + popover },
        popover === "profile"
          ? h(
              React.Fragment,
              null,
              h("div", { className: "small-label" }, "Your workspace"),
              h("h3", { className: "mt-2" }, "Kai"),
              h("p", null, "Logistics Operations Manager"),
              h(
                "div",
                { className: "popover-line" },
                h("span", { className: "text-green-300" }, "● "),
                "Global operations · Online",
              ),
            )
          : popover === "notifications"
            ? h(
                React.Fragment,
                null,
                h("h3", null, "Notifications"),
                h("p", null, "AA-845 is on schedule for arrival in Colombia."),
                h(
                  "div",
                  { className: "popover-line" },
                  h("p", null, "MU-131 has arrived at its destination."),
                  h("span", { className: "small-label" }, "Demo activity feed"),
                ),
              )
            : h(
                React.Fragment,
                null,
                h("h3", null, "View settings"),
                h(
                  "p",
                  null,
                  "Sunlight follows the current UTC time. City lights are hidden on the day side. Theme buttons only change the interface.",
                ),
                h(
                  "div",
                  { className: "setting-line" },
                  "Smooth motion",
                  h("button", {
                    className: "switch " + (motion ? "on" : ""),
                    role: "switch",
                    "aria-checked": motion,
                    "aria-label": "Smooth motion",
                    onClick: () => setMotion((v) => !v),
                  }),
                ),
                h(
                  "p",
                  null,
                  "Drag the Earth to rotate, or drag the flat map to pan. Scroll or pinch to zoom up to 8×. Center plane uses the selected flight's current estimated position and preserves zoom.",
                ),
                h(
                  "p",
                  null,
                  "Keyboard: arrows to rotate, + / − to zoom, N for north-up, Home to reset. North-up preserves the center and zoom.",
                ),
              ),
      ),
    modal &&
      h(
        "div",
        {
          className: "modal-backdrop",
          onClick: (e) => {
            if (e.target === e.currentTarget) setModal(null);
          },
        },
        h(
          "section",
          {
            className: "modal",
            ref: modalRef,
            role: "dialog",
            "aria-modal": true,
            "aria-labelledby": "modal-title",
          },
          h(
            "button",
            {
              className: "round-button close",
              "aria-label": "Close dialog",
              onClick: () => setModal(null),
            },
            h(Icon, { name: "close", size: 17 }),
          ),
          h(
            "span",
            { className: "modal-kicker" },
            modal === "risk"
              ? "Predictive intelligence"
              : "Orbital / Global operations",
          ),
          h(
            "h2",
            { id: "modal-title" },
            {
              how: "Your world. Connected.",
              risk: "A clearer view of risk.",
              analytics: "Every delivery counts.",
              team: "One connected team.",
              workspace: "Welcome to Orbital.",
              shipment: c.id + " · Shipment overview",
            }[modal],
          ),
          h(
            "p",
            null,
            {
              how: "Explore every shipment in one global view. Select a route on the Earth, then open Activities & insights to see the details.",
              risk: `${c.id} has an estimated ${c.risk}% loss risk in this demonstration. Clear skies and stable conditions keep this route in the low-risk range.`,
              analytics:
                "1,021 deliveries this month, up 32% from the previous period. 4,603 deliveries this year, up 12% year over year.",
              team: "Your global operations team keeps every shipment moving, from origin to destination.",
              workspace:
                "An interactive logistics concept with illustrative shipment data. Explore the Earth, follow routes, and uncover shipment insights.",
              shipment: `${c.from} → ${c.to} · ${c.distance} miles. Expected arrival: ${c.date}. Current status: ${c.status}.`,
            }[modal],
          ),
          h(
            "div",
            { className: "modal-items" },
            ...(modal === "how"
              ? [
                  "Drag to explore the 3D Earth",
                  "Select a cargo marker to follow its route",
                  "Open activities for shipment and weather insights",
                ]
              : modal === "risk"
                ? [
                    "Weather · Sunny, 32°C",
                    "Route conditions · Clear",
                    "Risk level · Low",
                  ]
                : modal === "team"
                  ? [
                      "Evan Harrison · Operations Manager",
                      "Mia Chen · Route Planning",
                      "Alex Rivera · Cargo Coordination",
                    ]
                  : modal === "analytics"
                    ? [
                        "Monthly growth · +32%",
                        "Annual growth · +12%",
                        "Active shipments · 3 pending, 1 arrived",
                      ]
                    : modal === "shipment"
                      ? [
                          "Transport · " +
                            {
                              plane: "Air freight",
                              ship: "Ocean freight",
                              truck: "Road freight",
                            }[c.icon],
                          "Route · " + c.from + " to " + c.to,
                          "Risk estimate · " + c.risk + "%",
                        ]
                      : [
                          "Real-time 3D exploration",
                          "Four illustrative cargo movements",
                          "Built for a connected world",
                        ]
            ).map((text, i) =>
              h(
                "div",
                { className: "modal-item", key: text },
                h("span", { className: "step" }, i + 1),
                text,
              ),
            ),
          ),
          h(
            "button",
            {
              className: "primary-button",
              onClick: () => {
                setModal(null);
                if (modal === "how" || modal === "shipment") setOpen(true);
              },
            },
            modal === "how" ? "Explore activities" : "Back to global view",
          ),
        ),
      ),
    toast && h("div", { className: "toast", role: "status" }, toast),
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(h(App));
