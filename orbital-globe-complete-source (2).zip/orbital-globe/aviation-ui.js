import {
  estimateFlightPosition,
  flightStatusText,
  routeDistanceKm,
} from "./aviation-core.js";
const { createElement: h, useState, useEffect, useRef } = React;
const airportCode = (a) => a?.iata || a?.icao || a?.id || "未知";
const safeURL = (value) => {
  try {
    const u = new URL(value);
    return u.protocol === "https:" ? u.href : null;
  } catch {
    return null;
  }
};
const timeText = (value) =>
  value
    ? new Date(value).toLocaleString("zh-CN", {
        timeZone: "UTC",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }) + " UTC"
    : "未提供";
async function api(url, signal) {
  const res = await fetch(url, { signal });
  let body;
  try {
    body = await res.json();
  } catch {
    throw new Error(
      "请使用 Node 后端启动：node server.mjs。纯静态服务器不支持机场/航班查询。",
    );
  }
  if (!res.ok) throw new Error(body.error || "查询失败");
  return body;
}
export function AviationPanel({ selection, onSelect, onClose, onFocus }) {
  const [tab, setTab] = useState("airports"),
    [query, setQuery] = useState(""),
    [family, setFamily] = useState("all");
  const [meta, setMeta] = useState(null),
    [results, setResults] = useState([]),
    [total, setTotal] = useState(0),
    [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false),
    [error, setError] = useState(""),
    [warnings, setWarnings] = useState([]),
    [online, setOnline] = useState(true);
  const [clock, setClock] = useState(Date.now()),
    [refreshing, setRefreshing] = useState(false);
  const generation = useRef(0),
    searchAbort = useRef(null),
    refreshAbort = useRef(null),
    debounce = useRef(null),
    selectionRef = useRef(selection),
    skipAutomaticSearch = useRef(false);
  selectionRef.current = selection;
  useEffect(() => {
    const controller = new AbortController();
    api("/api/meta", controller.signal)
      .then(setMeta)
      .catch((e) => {
        if (e.name !== "AbortError") setError(e.message);
      });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    const id = setInterval(() => setClock(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  useEffect(
    () => () => {
      searchAbort.current?.abort();
      refreshAbort.current?.abort();
    },
    [],
  );
  async function search({ live = false, page = 0, value = query } = {}) {
    clearTimeout(debounce.current);
    searchAbort.current?.abort();
    const controller = new AbortController();
    searchAbort.current = controller;
    const turn = ++generation.current;
    setLoading(true);
    setError("");
    setWarnings([]);
    try {
      const params = new URLSearchParams({
        q: value,
        family,
        offset: String(page),
        limit: "30",
        live: live ? "1" : "0",
      });
      const body = await api(`/api/${tab}?${params}`, controller.signal);
      if (generation.current !== turn) return;
      setResults(body.airports || body.flights || []);
      setTotal(body.total ?? body.flights?.length ?? 0);
      setOffset(page);
      setWarnings(body.warnings || []);
      if (body.usedOfflineFallback)
        setWarnings((w) => [
          ...w,
          { message: "未取得当前班次；展示离线参考航线，不代表今日执行。" },
        ]);
    } catch (e) {
      if (e.name !== "AbortError" && generation.current === turn) {
        setError(e.message);
        setResults([]);
      }
    } finally {
      if (generation.current === turn) setLoading(false);
    }
  }
  useEffect(() => {
    if (skipAutomaticSearch.current) {
      skipAutomaticSearch.current = false;
      return;
    }
    const timer = setTimeout(() => search({ live: false }), 250);
    debounce.current = timer;
    return () => {
      clearTimeout(timer);
      searchAbort.current?.abort();
      generation.current++;
    };
  }, [tab, query, family]);
  async function refreshSelected() {
    const current = selectionRef.current;
    if (current?.kind !== "flight" || !meta?.liveConfigured || refreshing)
      return;
    refreshAbort.current?.abort();
    const controller = new AbortController();
    refreshAbort.current = controller;
    setRefreshing(true);
    setError("");
    try {
      const body = await api(
        `/api/flights?${new URLSearchParams({ q: current.flight.number, live: "1" })}`,
        controller.signal,
      );
      if (selectionRef.current?.flight?.id !== current.flight.id) return;
      // Never silently switch a flight number to a different date or leg.
      const candidate = current.flight.live
        ? body.flights.find((f) => f.id === current.flight.id && f.live)
        : null;
      if (candidate) onSelect({ kind: "flight", flight: candidate }, false);
      else if (current.flight.live) {
        onSelect(
          { kind: "flight", flight: { ...current.flight, stale: true } },
          false,
        );
        setError("未能更新所选日期与航段，请重新查询并选择班次。");
      } else {
        clearTimeout(debounce.current);
        searchAbort.current?.abort();
        generation.current++;
        if (tab !== "flights" || query !== current.flight.number) {
          skipAutomaticSearch.current = true;
          setTab("flights");
          setQuery(current.flight.number);
        }
        setLoading(false);
        setOffset(0);
        setResults(body.flights || []);
        setTotal(body.flights?.length || 0);
        setWarnings([
          { message: "请选择要跟踪的实际班次。" },
          ...(body.warnings || []),
        ]);
      }
      if (current.flight.live) setWarnings(body.warnings || []);
    } catch (e) {
      if (e.name !== "AbortError") {
        setError(e.message);
        if (
          selectionRef.current?.flight?.id === current.flight.id &&
          current.flight.live
        )
          onSelect(
            { kind: "flight", flight: { ...current.flight, stale: true } },
            false,
          );
      }
    } finally {
      setRefreshing(false);
    }
  }
  useEffect(() => {
    if (
      selection?.kind !== "flight" ||
      !selection.flight.live ||
      !meta?.liveConfigured
    )
      return;
    const tick = () => {
      if (!document.hidden) refreshSelected();
    };
    const interval = setInterval(tick, 120000);
    const visible = () => {
      if (
        !document.hidden &&
        Date.now() - Date.parse(selectionRef.current?.flight?.fetchedAt || "") >
          120000
      )
        tick();
    };
    document.addEventListener("visibilitychange", visible);
    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", visible);
      refreshAbort.current?.abort();
    };
  }, [selection?.flight?.id, selection?.flight?.live, meta?.liveConfigured]);

  const flight = selection?.kind === "flight" ? selection.flight : null;
  const airport = selection?.kind === "airport" ? selection.airport : null;
  const estimate = flight ? estimateFlightPosition(flight, clock) : null;
  const sourceLink = (url, label) =>
    safeURL(url) &&
    h("a", { href: safeURL(url), target: "_blank", rel: "noreferrer" }, label);
  return h(
    "section",
    { className: "aviation-panel", "aria-label": "机场与客运航班搜索" },
    h(
      "div",
      { className: "aviation-title" },
      h(
        "div",
        null,
        h("span", { className: "aviation-kicker" }, "A380 / BOEING 787"),
        h("h2", null, "探索机场与航班"),
      ),
      h(
        "button",
        {
          className: "round-button",
          onClick: onClose,
          "aria-label": "关闭航班搜索",
        },
        "×",
      ),
    ),
    h(
      "div",
      { className: "aviation-tabs", role: "group", "aria-label": "搜索类型" },
      ...[
        ["airports", "机场"],
        ["flights", "客运航班"],
      ].map(([key, label]) =>
        h(
          "button",
          {
            key,
            className: tab === key ? "selected" : "",
            "aria-pressed": tab === key,
            onClick: () => {
              setTab(key);
              setQuery("");
              setResults([]);
              setWarnings([]);
            },
          },
          label,
        ),
      ),
    ),
    h(
      "form",
      {
        className: "aviation-form",
        onSubmit: (e) => {
          e.preventDefault();
          search({ live: tab === "flights" && online });
        },
      },
      h(
        "label",
        { className: "sr-only", htmlFor: "aviation-query" },
        tab === "airports" ? "机场代码、名称或城市" : "完整航班号",
      ),
      h(
        "div",
        { className: "aviation-search-line" },
        h("input", {
          id: "aviation-query",
          value: query,
          maxLength: 100,
          onChange: (e) => setQuery(e.target.value),
          placeholder:
            tab === "airports"
              ? "机场 / 城市 / IATA / ICAO"
              : "例如 NH184、QF9、EK001",
          autoComplete: "off",
        }),
        h(
          "button",
          { type: "submit", disabled: loading },
          loading ? "查询中" : "搜索",
        ),
      ),
      h(
        "div",
        { className: "aviation-filters" },
        h(
          "select",
          {
            value: family,
            onChange: (e) => setFamily(e.target.value),
            "aria-label": "机型筛选",
          },
          h(
            "option",
            { value: "all" },
            tab === "airports" ? "全部机场" : "A380 + 787",
          ),
          h("option", { value: "A380" }, "A380 使用记录"),
          h("option", { value: "B787" }, "787 使用记录"),
        ),
        tab === "flights" &&
          h(
            "label",
            null,
            h("input", {
              type: "checkbox",
              checked: online,
              onChange: (e) => setOnline(e.target.checked),
            }),
            "联网查状态",
          ),
      ),
    ),
    h(
      "div",
      { className: "aviation-scroll" },
      error && h("p", { className: "aviation-error", role: "alert" }, error),
      ...warnings.map((w, i) =>
        h(
          "p",
          { key: i, className: "aviation-note", role: "status" },
          w.message,
        ),
      ),
      flight &&
        h(
          "section",
          { className: "aviation-detail" },
          h(
            "div",
            { className: "aviation-detail-heading" },
            h("h3", null, flight.number),
            h(
              "span",
              { className: "aviation-badge" },
              flight.aircraftType || "机型未知",
            ),
          ),
          h(
            "div",
            { className: "aviation-route-name" },
            `${flight.originCode} → ${flight.destinationCode}`,
          ),
          h("p", { className: "aviation-status" }, flightStatusText(flight)),
          !flight.family &&
            h(
              "p",
              { className: "aviation-note" },
              "当班机型不属于 A380/787，或数据源尚未提供机型。",
            ),
          flight.aircraftEvidence === "catalog" &&
            h(
              "p",
              { className: "aviation-note" },
              "机型来自参考航线，尚未确认当班机型。",
            ),
          h(
            "dl",
            { className: "aviation-facts" },
            h("dt", null, "计划起飞"),
            h("dd", null, timeText(flight.times?.scheduledDeparture)),
            h("dt", null, "预计到达"),
            h("dd", null, timeText(flight.times?.estimatedArrival)),
            h("dt", null, "飞行时长"),
            h(
              "dd",
              null,
              flight.durationMinutes
                ? `${Math.floor(flight.durationMinutes / 60)} 小时 ${Math.round(flight.durationMinutes % 60)} 分${flight.durationBasis === "schedule-difference" ? "（计划时差）" : ""}`
                : "未提供",
            ),
            h("dt", null, "大圆距离"),
            h(
              "dd",
              null,
              flight.origin && flight.destination
                ? `${Math.round(routeDistanceKm([flight.origin.lat, flight.origin.lon], [flight.destination.lat, flight.destination.lon])).toLocaleString()} km`
                : "坐标未匹配",
            ),
            h("dt", null, "状态获取"),
            h(
              "dd",
              null,
              flight.live ? timeText(flight.fetchedAt) : "离线参考",
            ),
          ),
          estimate.progress != null &&
            h("progress", {
              value: estimate.progress,
              max: 1,
              "aria-label": "估算航程进度",
            }),
          h(
            "p",
            { className: "aviation-estimate" },
            estimate.kind === "estimated"
              ? `估算航程 ${Math.round(estimate.progress * 100)}% · ${estimate.position[0].toFixed(2)}°, ${estimate.position[1].toFixed(2)}°`
              : estimate.reason,
          ),
          h(
            "p",
            { className: "aviation-muted" },
            "航线为机场间最短大圆；飞机位置按 ETA 与时长估算，不是实际航迹。",
          ),
          h(
            "div",
            { className: "aviation-actions" },
            h("button", { onClick: onFocus }, "定位航线"),
            h(
              "button",
              {
                onClick: refreshSelected,
                disabled: refreshing || !meta?.liveConfigured,
              },
              refreshing ? "更新中…" : "刷新状态",
            ),
            h("button", { onClick: () => onSelect(null) }, "清除"),
          ),
          sourceLink(
            flight.sourceUrl,
            `数据来源${flight.sourceAsOf ? " · " + flight.sourceAsOf : ""}`,
          ),
        ),
      airport &&
        h(
          "section",
          { className: "aviation-detail" },
          h(
            "div",
            { className: "aviation-detail-heading" },
            h("h3", null, airportCode(airport)),
            h(
              "span",
              { className: "aviation-badge" },
              airport.icao || airport.id,
            ),
          ),
          h("p", null, airport.name),
          h(
            "p",
            { className: "aviation-muted" },
            `${airport.city} · ${airport.country} · ${airport.lat.toFixed(4)}°, ${airport.lon.toFixed(4)}°`,
          ),
          airport.runway &&
            h(
              "p",
              { className: "aviation-muted" },
              `最长登记跑道 ${airport.runway.lengthM.toLocaleString()} m${airport.runway.widthM ? " × " + airport.runway.widthM + " m" : ""}；不据此判定机型适用性。`,
            ),
          airport.evidence.length
            ? airport.evidence.map((e, i) =>
                h(
                  "p",
                  { key: i, className: "aviation-evidence" },
                  `${e.family} · ${e.kind === "airport-published" ? "机场方资料" : "航线使用记录"} · ${e.asOf || "日期未知"} `,
                  sourceLink(e.source, "来源"),
                ),
              )
            : h(
                "p",
                { className: "aviation-note" },
                "尚无已导入的 A380/787 使用或机场批准资料。此标记不表示不能起降。",
              ),
          h(
            "div",
            { className: "aviation-actions" },
            h("button", { onClick: onFocus }, "定位机场"),
            h("button", { onClick: () => onSelect(null) }, "清除"),
          ),
        ),
      h(
        "div",
        { className: "aviation-results-heading" },
        h(
          "span",
          null,
          `${tab === "airports" ? "机场" : "航线 / 班次"}结果 · ${total.toLocaleString()}`,
        ),
        tab === "flights" && h("span", null, "请选择日期与航段"),
      ),
      h(
        "div",
        { className: "aviation-results", "aria-busy": loading },
        ...results.map((row) =>
          tab === "airports"
            ? h(
                "button",
                {
                  className: "aviation-result",
                  key: row.id,
                  onClick: () => onSelect({ kind: "airport", airport: row }),
                },
                h("strong", null, airportCode(row)),
                h(
                  "span",
                  null,
                  row.name,
                  h(
                    "small",
                    null,
                    `${row.city || row.country} · ${row.icao || row.id} · ${row.evidence.length ? [...new Set(row.evidence.map((e) => e.family))].join(" / ") + " 使用记录" : "机型能力未核实"}`,
                  ),
                ),
              )
            : h(
                "button",
                {
                  className: "aviation-result flight-result",
                  key: row.id,
                  onClick: () => onSelect({ kind: "flight", flight: row }),
                },
                h("strong", null, row.number),
                h(
                  "span",
                  null,
                  `${row.originCode} → ${row.destinationCode}`,
                  h(
                    "small",
                    null,
                    `${row.aircraftType || "机型未知"} · ${row.live ? timeText(row.times?.scheduledDeparture) : "离线参考，非今日航班"}`,
                  ),
                  h(
                    "small",
                    null,
                    row.live ? flightStatusText(row) : row.operator,
                  ),
                ),
              ),
        ),
      ),
      !loading &&
        results.length === 0 &&
        h(
          "p",
          { className: "aviation-muted" },
          tab === "flights"
            ? "本地没有匹配航线。输入完整航班号后点搜索可查询联网数据；也可先同步或导入航线库。"
            : "没有匹配机场。请尝试 IATA/ICAO 代码或英文名称，并检查机型筛选。",
        ),
      tab === "airports" &&
        total > 30 &&
        h(
          "div",
          { className: "aviation-actions" },
          h(
            "button",
            {
              disabled: offset === 0 || loading,
              onClick: () => search({ page: Math.max(0, offset - 30) }),
            },
            "上一页",
          ),
          h("span", null, `${offset + 1}–${Math.min(offset + 30, total)}`),
          h(
            "button",
            {
              disabled: offset + 30 >= total || loading,
              onClick: () => search({ page: offset + 30 }),
            },
            "下一页",
          ),
        ),
      h(
        "details",
        { className: "aviation-coverage" },
        h("summary", null, "数据覆盖与连接"),
        h(
          "p",
          null,
          meta
            ? `${meta.airports.toLocaleString()} 个机场 · ${meta.catalogRoutes} 条参考/同步航线 · 实时接口${meta.liveConfigured ? "已配置" : "未配置"}`
            : "正在读取后端状态…",
        ),
        h("p", null, meta?.coverage || "请通过 node server.mjs 启动。"),
        h(
          "p",
          null,
          "实时状态约每 2 分钟刷新；后台接口结果缓存 2 分钟。完整数据导入与密钥设置见 FLIGHT-SETUP.md。",
        ),
        sourceLink("https://ourairports.com/data/", "机场数据 · OurAirports"),
      ),
    ),
  );
}
