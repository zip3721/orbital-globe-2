// This uses the user's provider quota only when explicitly run.
import { readFile, writeFile, mkdir, rename } from "node:fs/promises";
import { createAirLabs } from "../backend/airlabs.mjs";
import { loadEnv } from "../backend/config.mjs";
import { aircraftFamily, normalizeFlightNumber } from "../aviation-core.js";
const root = new URL("../", import.meta.url);
loadEnv(root);
const args = process.argv.slice(2);
const option = (key) =>
  args.find((a) => a.startsWith(key + "="))?.slice(key.length + 1);
if (
  !args.includes("--all-passenger") &&
  !option("--airlines") &&
  !args.includes("--resume")
) {
  console.log(
    "Usage: node scripts/sync-catalog.mjs --airlines=NH,QF,EK [--max-requests=200]\n       node scripts/sync-catalog.mjs --all-passenger [--max-requests=200]\n       node scripts/sync-catalog.mjs --resume [--max-requests=200]\nProvider quota may be consumed. Coverage is limited to data returned by your plan.",
  );
  process.exit(0);
}
const provider = createAirLabs();
if (!provider.configured)
  throw new Error("Configure AIRLABS_API_KEY in .env first.");
const budget = Number(option("--max-requests") || 200);
if (!Number.isInteger(budget) || budget < 1 || budget > 100000)
  throw new Error("Invalid request budget");
const runtime = new URL(".runtime/", root);
await mkdir(runtime, { recursive: true });
const statePath = new URL("sync-state.json", runtime),
  catalogPath = new URL("data/flights.catalog.json", root);
async function readJSON(url, fallback) {
  try {
    return JSON.parse(await readFile(url, "utf8"));
  } catch (e) {
    if (e.code === "ENOENT") return fallback;
    throw e;
  }
}
async function atomic(url, data) {
  const temp = new URL(url.href + ".tmp");
  await writeFile(temp, JSON.stringify(data, null, 2) + "\n");
  await rename(temp, url);
}
let requests = 0,
  state;
const previous = await readJSON(catalogPath, { flights: [] });
const routes = new Map(
  previous.flights.map((f) => [
    [f.number, f.originCode, f.destinationCode].join("|"),
    f,
  ]),
);
if (args.includes("--resume")) {
  state = await readJSON(statePath, null);
  if (!state) throw new Error("No interrupted sync to resume.");
} else {
  const body = await provider.request("airlines");
  requests++;
  if (!Array.isArray(body.response))
    throw new Error("Invalid airlines response");
  const requested = option("--airlines")?.toUpperCase().split(",");
  const passengers = body.response.filter(
    (a) => Number(a.is_passenger) === 1 && (a.iata_code || a.icao_code),
  );
  const airlines = passengers.filter(
    (a) =>
      !requested ||
      requested.includes(a.iata_code) ||
      requested.includes(a.icao_code),
  );
  if (!airlines.length)
    throw new Error(
      "No passenger airlines found. Your plan may not expose is_passenger, or the airline codes are invalid.",
    );
  state = {
    scope: requested || "provider-passenger-airlines",
    airlines: airlines.map((a) => ({
      iata: a.iata_code || null,
      icao: a.icao_code || null,
      name: a.name,
    })),
    index: 0,
    offset: 0,
    scanned: 0,
    startedAt: new Date().toISOString(),
    missingPassengerFlags: body.response.filter((a) => a.is_passenger == null)
      .length,
    lastSignature: null,
  };
}
let failure = null;
while (state.index < state.airlines.length && requests < budget) {
  const airline = state.airlines[state.index];
  try {
    const filter = airline.iata
      ? { airline_iata: airline.iata }
      : { airline_icao: airline.icao };
    const body = await provider.request("routes", {
      ...filter,
      limit: 50,
      offset: state.offset,
    });
    requests++;
    const rows = body.response;
    if (!Array.isArray(rows)) throw new Error("Invalid route response");
    const signature = JSON.stringify([rows.length, rows[0], rows.at(-1)]);
    if (state.offset > 0 && rows.length && signature === state.lastSignature)
      throw new Error(
        "Provider repeated a page; pagination stopped rather than claiming completeness.",
      );
    state.lastSignature = signature;
    for (const r of rows) {
      state.scanned++;
      const number = normalizeFlightNumber(r.flight_iata || r.flight_icao);
      if (
        !number ||
        !aircraftFamily(r.aircraft_icao) ||
        !(r.dep_iata || r.dep_icao) ||
        !(r.arr_iata || r.arr_icao)
      )
        continue;
      const row = {
        number,
        icaoNumber: normalizeFlightNumber(r.flight_icao),
        operator: airline.name,
        originCode: r.dep_iata || r.dep_icao,
        destinationCode: r.arr_iata || r.arr_icao,
        aircraftType: r.aircraft_icao,
        durationMinutes: Number(r.duration) > 0 ? Number(r.duration) : null,
        days: r.days || [],
        codeshares: r.cs_flight_iata
          ? [normalizeFlightNumber(r.cs_flight_iata)].filter(Boolean)
          : [],
        source: "AirLabs route database (last used aircraft)",
        sourceUrl: "https://airlabs.co/docs/routes",
        sourceAsOf: r.updated || null,
        fetchedAt: new Date().toISOString(),
        passengerEvidence: "provider-passenger-airline",
        referenceOnly: true,
      };
      routes.set(
        [row.number, row.originCode, row.destinationCode].join("|"),
        row,
      );
    }
    const more =
      body.request?.has_more === true ||
      (body.request?.has_more == null && rows.length === 50);
    if (more && rows.length === 0)
      throw new Error(
        "Provider indicates more data but returned an empty page.",
      );
    if (more) state.offset += rows.length;
    else {
      state.index++;
      state.offset = 0;
      state.lastSignature = null;
    }
    await atomic(statePath, state);
    await atomic(catalogPath, {
      metadata: {
        complete: false,
        completeForProviderScope: state.index === state.airlines.length,
        state:
          state.index === state.airlines.length
            ? "provider-scope-scanned"
            : "partial",
        scope: state.scope,
        airlinesFinished: state.index,
        airlinesTotal: state.airlines.length,
        recordsScanned: state.scanned,
        missingPassengerFlags: state.missingPassengerFlags,
        syncedAt: new Date().toISOString(),
        note: "Last-used aircraft route records from passenger airlines, not a guarantee of every flight or current airport approval. Existing imported routes are retained.",
      },
      flights: [...routes.values()],
    });
    console.log(
      `${airline.iata || airline.icao}: ${state.index}/${state.airlines.length} airlines; ${routes.size} target routes; ${requests}/${budget} requests`,
    );
  } catch (error) {
    failure = error.message;
    break;
  }
}
await atomic(statePath, state);
if (failure) {
  console.error(
    `Sync paused: ${failure}. Run with --resume after fixing the issue.`,
  );
  process.exitCode = 1;
} else if (state.index < state.airlines.length)
  console.log(
    "Request budget reached. Partial catalog saved; continue with --resume.",
  );
else
  console.log(
    "Provider scope scanned. This is not a claim of complete worldwide coverage. Restart the server.",
  );
