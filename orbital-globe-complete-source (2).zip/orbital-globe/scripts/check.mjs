import { readdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
const root = new URL("../", import.meta.url);
const files = [
  "app.js",
  "aviation-ui.js",
  "aviation-core.js",
  "globe-navigation.js",
  "solar.js",
  "earth-shaders.js",
  "server.mjs",
];
for (const folder of ["backend", "scripts", "tests"])
  for (const name of await readdir(new URL(folder + "/", root)))
    if (/\.(mjs|js)$/.test(name)) files.push(folder + "/" + name);
for (const name of files) {
  const result = spawnSync(
    process.execPath,
    ["--check", fileURLToPath(new URL(name, root))],
    { stdio: "inherit" },
  );
  if (result.status !== 0) process.exit(result.status || 1);
}
console.log(`Syntax OK: ${files.length} JavaScript files`);
