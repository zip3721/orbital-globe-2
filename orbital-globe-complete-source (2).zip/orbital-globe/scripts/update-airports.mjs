import { readFile, writeFile, rename } from "node:fs/promises";
import { parseCSV } from "../backend/csv.mjs";
const root = new URL("../data/", import.meta.url);
async function download(name) {
  const response = await fetch(
    `https://raw.githubusercontent.com/davidmegginson/ourairports-data/main/${name}.csv`,
    { signal: AbortSignal.timeout(90000) },
  );
  if (!response.ok)
    throw new Error(`Airport download failed (${response.status})`);
  return parseCSV(await response.text());
}
const [rows, strips] = await Promise.all([
  download("airports"),
  download("runways"),
]);
const aliases = JSON.parse(
  await readFile(new URL("airport-aliases.json", root), "utf8"),
);
const runways = new Map();
for (const r of strips) {
  const lengthM = Math.round(Number(r.length_ft) * 0.3048);
  if (r.closed === "1" || !(lengthM > 0)) continue;
  if (
    !runways.has(r.airport_ident) ||
    runways.get(r.airport_ident).lengthM < lengthM
  )
    runways.set(r.airport_ident, {
      lengthM,
      widthM: r.width_ft ? Math.round(Number(r.width_ft) * 0.3048) : null,
      surface: r.surface,
    });
}
const airports = rows
  .filter(
    (r) =>
      ["large_airport", "medium_airport", "small_airport"].includes(r.type) &&
      r.latitude_deg !== "" &&
      r.longitude_deg !== "" &&
      Number.isFinite(Number(r.latitude_deg)) &&
      Number.isFinite(Number(r.longitude_deg)) &&
      Math.abs(Number(r.latitude_deg)) <= 90 &&
      Math.abs(Number(r.longitude_deg)) <= 180,
  )
  .map((r) => ({
    id: r.ident,
    icao: r.icao_code || null,
    iata: r.iata_code || null,
    name: r.name,
    city: r.municipality,
    country: r.iso_country,
    lat: Number(r.latitude_deg),
    lon: Number(r.longitude_deg),
    type: r.type,
    scheduled: r.scheduled_service === "yes",
    aliases: aliases[r.iata_code] || [],
    runway: runways.get(r.ident) || null,
  }));
if (airports.length < 10000)
  throw new Error(
    "Downloaded airport database is unexpectedly small; existing database preserved.",
  );
const payload = {
  metadata: {
    source: "OurAirports",
    sourceUrl: "https://ourairports.com/data/",
    downloadedAt: new Date().toISOString(),
    scope:
      "Open fixed-wing airports with valid coordinates; not an A380/B787 approval list.",
    count: airports.length,
    license: "Public domain",
  },
  airports,
};
await writeFile(new URL("airports.json.tmp", root), JSON.stringify(payload));
await rename(
  new URL("airports.json.tmp", root),
  new URL("airports.json", root),
);
console.log(
  `Updated ${airports.length} airports. Restart the server to load them.`,
);
