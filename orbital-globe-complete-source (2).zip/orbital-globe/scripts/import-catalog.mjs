import { readFile, writeFile, rename } from "node:fs/promises";
import path from "node:path";
import { aircraftFamily, normalizeFlightNumber } from "../aviation-core.js";
import { parseCSV } from "../backend/csv.mjs";
const filename = process.argv[2];
if (!filename) {
  console.log(
    "Usage: node scripts/import-catalog.mjs <licensed-routes.json|csv>",
  );
  process.exit(0);
}
const text = await readFile(path.resolve(filename), "utf8");
const payload = filename.toLowerCase().endsWith(".csv")
  ? parseCSV(text)
  : JSON.parse(text);
const rows = Array.isArray(payload) ? payload : payload.flights;
if (!Array.isArray(rows))
  throw new Error("Expected an array or { flights: [...] }");
const destination = new URL("../data/flights.catalog.json", import.meta.url);
const existing = JSON.parse(await readFile(destination, "utf8"));
const map = new Map(
  existing.flights.map((f) => [
    [f.number, f.originCode, f.destinationCode].join("|"),
    f,
  ]),
);
let accepted = 0,
  skipped = 0;
for (const [index, r] of rows.entries()) {
  if (!aircraftFamily(r.aircraftType)) {
    skipped++;
    continue;
  }
  const number = normalizeFlightNumber(r.number),
    originCode = String(r.originCode || "").toUpperCase(),
    destinationCode = String(r.destinationCode || "").toUpperCase();
  if (
    !number ||
    !/^[A-Z0-9-]{3,12}$/.test(originCode) ||
    !/^[A-Z0-9-]{3,12}$/.test(destinationCode) ||
    !r.sourceUrl ||
    !r.sourceAsOf
  )
    throw new Error(
      `Row ${index + 1}: number, airport codes, sourceUrl and sourceAsOf are required. No changes written.`,
    );
  const row = {
    number,
    icaoNumber: normalizeFlightNumber(r.icaoNumber),
    originCode,
    destinationCode,
    operator: String(r.operator || ""),
    aircraftType: String(r.aircraftType).toUpperCase(),
    durationMinutes:
      Number(r.durationMinutes) > 0 ? Number(r.durationMinutes) : null,
    source: "User-imported route source",
    sourceUrl: String(r.sourceUrl),
    sourceAsOf: String(r.sourceAsOf),
    passengerEvidence: String(r.passengerEvidence || "import-unclassified"),
    referenceOnly: true,
  };
  map.set([number, originCode, destinationCode].join("|"), row);
  accepted++;
}
const output = {
  metadata: {
    ...existing.metadata,
    complete: false,
    state: "imported",
    importedAt: new Date().toISOString(),
    note: "User-supplied route records; coverage and licensing remain those of the supplied source.",
  },
  flights: [...map.values()],
};
const temp = new URL(destination.href + ".tmp");
await writeFile(temp, JSON.stringify(output, null, 2) + "\n");
await rename(temp, destination);
console.log(
  `Imported ${accepted} target routes; skipped ${skipped} other aircraft. Restart the server.`,
);
